<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'cbd4aceb30ed30846ab500dae2ae24da',
      'native_key' => 'core',
      'filename' => 'modNamespace/fd0e36b3a2e34bd20630a13456f22b1d.vehicle',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modWorkspace',
      'guid' => '05803316dca2678ada3f9d2cee14701a',
      'native_key' => 1,
      'filename' => 'modWorkspace/f126e754ea8f9d3fce66a9ae804795b8.vehicle',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modTransportProvider',
      'guid' => 'c91085de16082af6fda5649dadcf17bd',
      'native_key' => 1,
      'filename' => 'modTransportProvider/10880b145afbe31b65ce95dd27a1287a.vehicle',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'f53200321df42537c482e16f39afa28a',
      'native_key' => 'topnav',
      'filename' => 'modMenu/efff1813130b989bdd6367220f053509.vehicle',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => '3d2c1186ca00c13a613c30e34ca52f33',
      'native_key' => 'usernav',
      'filename' => 'modMenu/0b9d892503171370093ec5b309dddd3e.vehicle',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'ff3eeb5277eec62dcace197799be88d3',
      'native_key' => 1,
      'filename' => 'modContentType/b7618bca2f3cda4a87bfeb87a480957e.vehicle',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'cff8ac2aecd923592b00ea8cf6789972',
      'native_key' => 2,
      'filename' => 'modContentType/972fd58a3beb8749609b3f097d3ec6cf.vehicle',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '23d684599693e424e157bd6cb111121b',
      'native_key' => 3,
      'filename' => 'modContentType/85f11aa340b941ea79a7af28a056d487.vehicle',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '0c30f59dd3d829b14d65a92cd90fddf6',
      'native_key' => 4,
      'filename' => 'modContentType/af805aaceb718eed60cde632d5fd76f2.vehicle',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'b13ce374845fb8fb9e0665e2b7839254',
      'native_key' => 5,
      'filename' => 'modContentType/1f8292c234c602eb0833920ed3ac98d8.vehicle',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => '93241bae4378eee599b3d4e350dcee45',
      'native_key' => 6,
      'filename' => 'modContentType/adf22e5136f8639eb37047c8a8686d22.vehicle',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'edee323afd77428052ca28258fead7d3',
      'native_key' => 7,
      'filename' => 'modContentType/3e326f8e8bdca87fc7b804e6fa2ceb41.vehicle',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContentType',
      'guid' => 'd0fc5d88184b34ea5b13f8408d4099d9',
      'native_key' => 8,
      'filename' => 'modContentType/f7f6b1189985fa8db74e0b20685d626f.vehicle',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '9d11deefcfdbf3c5567139673372c523',
      'native_key' => NULL,
      'filename' => 'modClassMap/034b31b8264ac06ed0690286ccc8271c.vehicle',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'a1b1121dda98180a23afb15615785d1e',
      'native_key' => NULL,
      'filename' => 'modClassMap/8b12b8f3d190880402c77492942849bc.vehicle',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '778abd97efc33d89a870c32bd3af3d9e',
      'native_key' => NULL,
      'filename' => 'modClassMap/de0974e4908dcad789f6d22c0b911e95.vehicle',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '91e07b3e72fe0e8174819a4465f89633',
      'native_key' => NULL,
      'filename' => 'modClassMap/32234bcf384ae029892a30f37d524e1d.vehicle',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '5c314f38db293ab8a416f4cd3a353036',
      'native_key' => NULL,
      'filename' => 'modClassMap/1048c8278937d0152868f7e4557c37d0.vehicle',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '84cecb0712441bb3429fdcfd8c7fad3d',
      'native_key' => NULL,
      'filename' => 'modClassMap/9beeffa83fa0bb754dd83aba0ba7dd5d.vehicle',
    ),
    19 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '80203ec24faad783ca23c30b3814665b',
      'native_key' => NULL,
      'filename' => 'modClassMap/95b3a8c76df5559b6a537992fafca722.vehicle',
    ),
    20 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => 'f555167ec64f1968cbb85e117fd20821',
      'native_key' => NULL,
      'filename' => 'modClassMap/39fc71864712848a83ef953a89cc19fb.vehicle',
    ),
    21 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modClassMap',
      'guid' => '758560bf777f83f3dc2fcc04e20f01e4',
      'native_key' => NULL,
      'filename' => 'modClassMap/2dcbfab3c9eeba5365add61273df9e31.vehicle',
    ),
    22 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd00347cdd4636b9d3172e62ab2aec788',
      'native_key' => 'OnPluginEventBeforeSave',
      'filename' => 'modEvent/2896247ca0b26768aba0709388b3e748.vehicle',
    ),
    23 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '43167f8cc4e9af35b40a0d3d8a91cb85',
      'native_key' => 'OnPluginEventSave',
      'filename' => 'modEvent/9947db60629cd1fc724317aebc18871e.vehicle',
    ),
    24 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3572baf609bb54b7237ded379bf8c638',
      'native_key' => 'OnPluginEventBeforeRemove',
      'filename' => 'modEvent/af7eabbcc3c8555524767469010646a4.vehicle',
    ),
    25 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2bd5c66f405f7ef11c9584f46c58a238',
      'native_key' => 'OnPluginEventRemove',
      'filename' => 'modEvent/f985dd2e858cd2a44924dda1bbbce609.vehicle',
    ),
    26 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '911fd7772aaaf31f101b86bc5156f1fa',
      'native_key' => 'OnResourceGroupSave',
      'filename' => 'modEvent/197787b16fe61c5d59a25f31609b5922.vehicle',
    ),
    27 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '430cd077fa9cf362dce374b32efe650b',
      'native_key' => 'OnResourceGroupBeforeSave',
      'filename' => 'modEvent/fbf5697ed04f3642310672edcfe582cf.vehicle',
    ),
    28 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9dc27db951fe6e8ecf0cbd03dbf19a07',
      'native_key' => 'OnResourceGroupRemove',
      'filename' => 'modEvent/eed763ea11ce3cc74049efacd41a2924.vehicle',
    ),
    29 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e531ee670bdbfcb778f04f3efd9e54f',
      'native_key' => 'OnResourceGroupBeforeRemove',
      'filename' => 'modEvent/5762c63e450a6a80b347c846e6cb10b7.vehicle',
    ),
    30 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9adfbf79ae6935c1a6c8dc4a40affb6f',
      'native_key' => 'OnSnippetBeforeSave',
      'filename' => 'modEvent/314978560599a22d86a1c6b743718a6d.vehicle',
    ),
    31 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbfc112d4a3ee17d93181e1ab69c8264',
      'native_key' => 'OnSnippetSave',
      'filename' => 'modEvent/232ebdb7c33944ce632c86cf32541160.vehicle',
    ),
    32 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ee2312340aaaef8c1c9891ad94cc4d34',
      'native_key' => 'OnSnippetBeforeRemove',
      'filename' => 'modEvent/6d209d4c3f92cb39696f897e42fe4b39.vehicle',
    ),
    33 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1daebec6140dc36fc09d72bc5130158f',
      'native_key' => 'OnSnippetRemove',
      'filename' => 'modEvent/bf17335bef11d31c9f4a7f09bb5b6ac9.vehicle',
    ),
    34 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f35835832adc6830ec7ffd9263fce032',
      'native_key' => 'OnSnipFormPrerender',
      'filename' => 'modEvent/c6fee0768f77265c71b1924bac2db9cc.vehicle',
    ),
    35 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b6fefecd948bd72c0ccdc66ecb6917ea',
      'native_key' => 'OnSnipFormRender',
      'filename' => 'modEvent/d3af25126f617ae7c3cf57994214ece3.vehicle',
    ),
    36 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '22d85a1fa02393d67cdd28b7e1973a93',
      'native_key' => 'OnBeforeSnipFormSave',
      'filename' => 'modEvent/eb74f99aec0b16abbfcda82061d2f779.vehicle',
    ),
    37 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '71d1ff8a0531ba477c7714d45882fde1',
      'native_key' => 'OnSnipFormSave',
      'filename' => 'modEvent/1d4fa0a42047e62842905c2ed23629ff.vehicle',
    ),
    38 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'edb83ba3d97928a0acbe333b36ff9974',
      'native_key' => 'OnBeforeSnipFormDelete',
      'filename' => 'modEvent/c04135f08161b20853b391d6f99ede92.vehicle',
    ),
    39 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6e0fa7e5f9769fe446aa975c07b853ae',
      'native_key' => 'OnSnipFormDelete',
      'filename' => 'modEvent/92395017b114f8b8a24420c6b46df5f6.vehicle',
    ),
    40 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05cc112996cf196cf4e9d59f194942e4',
      'native_key' => 'OnTemplateBeforeSave',
      'filename' => 'modEvent/0154f06a9b80da59a4cebb9d72dfbe89.vehicle',
    ),
    41 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f3b03f37e1bde16af39ab989f89f0f58',
      'native_key' => 'OnTemplateSave',
      'filename' => 'modEvent/73403dfb87672cd26b8f7799f3cd20ce.vehicle',
    ),
    42 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '15361814453a193221cb523d35a01068',
      'native_key' => 'OnTemplateBeforeRemove',
      'filename' => 'modEvent/5966360e6e99a1c766d7ea4a28f38d82.vehicle',
    ),
    43 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '175991f3863afe6b372399be62fdc0a8',
      'native_key' => 'OnTemplateRemove',
      'filename' => 'modEvent/23e75b1adc9226093c011240806d89a7.vehicle',
    ),
    44 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '63fe7b3ca26f91224938b48ce1e20d6e',
      'native_key' => 'OnTempFormPrerender',
      'filename' => 'modEvent/a384e36a7f08f186ceb9ce0e9abcc5dc.vehicle',
    ),
    45 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '858bd1cbb8eb69cee9c044eed592d2ad',
      'native_key' => 'OnTempFormRender',
      'filename' => 'modEvent/526d69328e7d995e5b02ff83faddd9f4.vehicle',
    ),
    46 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2008e16dbb8910ef44dacbed8370797f',
      'native_key' => 'OnBeforeTempFormSave',
      'filename' => 'modEvent/ac2137bc08c066e4b7a67b5b58fccce2.vehicle',
    ),
    47 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'def71c7821be1854e1bc5ebd609b55e5',
      'native_key' => 'OnTempFormSave',
      'filename' => 'modEvent/fe330394b20e933dc08d2b05deed658d.vehicle',
    ),
    48 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c50684f492169765efb482be50ddcdf3',
      'native_key' => 'OnBeforeTempFormDelete',
      'filename' => 'modEvent/2903e4ae3f1b28f327bf2d3716a096da.vehicle',
    ),
    49 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99ebe993ec2b80018ff05b4bb856a4f5',
      'native_key' => 'OnTempFormDelete',
      'filename' => 'modEvent/cf366266913a9e446029c3e56a6d0ede.vehicle',
    ),
    50 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '309ff227f62ee7c5525c2525499fd4d8',
      'native_key' => 'OnTemplateVarBeforeSave',
      'filename' => 'modEvent/d718dc59ad117052aab02b02ada0486b.vehicle',
    ),
    51 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fb3e7000d95700b8c67e82ebb842c30c',
      'native_key' => 'OnTemplateVarSave',
      'filename' => 'modEvent/affc09b627bd0cb3ff6cd828836de5d1.vehicle',
    ),
    52 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fca312f47f6f6930566eb9c0e7473fb0',
      'native_key' => 'OnTemplateVarBeforeRemove',
      'filename' => 'modEvent/cffdd6215b52e1ca899b45c2ebde39f1.vehicle',
    ),
    53 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f727c4f7a61fcbd0c6a0c76e29ea3545',
      'native_key' => 'OnTemplateVarRemove',
      'filename' => 'modEvent/2a4baac9835767701b33871e70ce7d0e.vehicle',
    ),
    54 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cdfd24eaee07b5084fc0c76bda60eec',
      'native_key' => 'OnTVFormPrerender',
      'filename' => 'modEvent/ef25a305295ffb00d65be090173416e9.vehicle',
    ),
    55 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7aa2b603300b0b45c6c745fad6d756ea',
      'native_key' => 'OnTVFormRender',
      'filename' => 'modEvent/35b1db30965ab88e0389fefbc0ae8697.vehicle',
    ),
    56 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '804000206afc7f5bdf6dd4d6900dd35d',
      'native_key' => 'OnBeforeTVFormSave',
      'filename' => 'modEvent/1b6b29c39c91535606cf56369ebad384.vehicle',
    ),
    57 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4207b47302f5ef7839909304d181bc82',
      'native_key' => 'OnTVFormSave',
      'filename' => 'modEvent/8208e38f2967fd5cbe716d3a484aa963.vehicle',
    ),
    58 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0a0fdba69091a815729eb76afeabffc7',
      'native_key' => 'OnBeforeTVFormDelete',
      'filename' => 'modEvent/f300439b5516d6134605b3f92827cac6.vehicle',
    ),
    59 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6c57bb0a2f2611b23c44d97d416db235',
      'native_key' => 'OnTVFormDelete',
      'filename' => 'modEvent/fa08b6bdc1f4bcc49911afba9da52e7c.vehicle',
    ),
    60 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '564a655cbe9a3e35dc4364c79dc3a14f',
      'native_key' => 'OnTVInputRenderList',
      'filename' => 'modEvent/958c3065eb23bb5d18b7db048ffb7f64.vehicle',
    ),
    61 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ad7344f4ceb7b17f06028dd0d6363f31',
      'native_key' => 'OnTVInputPropertiesList',
      'filename' => 'modEvent/961f769dfbc8f76e9b7c9f12ea38fe23.vehicle',
    ),
    62 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7bd8f963d74aa6996139d588689adf27',
      'native_key' => 'OnTVOutputRenderList',
      'filename' => 'modEvent/49dc5c5c0390093127a8932d1559a57c.vehicle',
    ),
    63 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '734b395d006ab475b55215fedbc5a3db',
      'native_key' => 'OnTVOutputRenderPropertiesList',
      'filename' => 'modEvent/77826a182ca4adbe39ed690346aa37d4.vehicle',
    ),
    64 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41a2f1809ccf6b825fd4f2dc47e46eaf',
      'native_key' => 'OnUserGroupBeforeSave',
      'filename' => 'modEvent/07f28f877276a23a660de2b3e4bbb6c1.vehicle',
    ),
    65 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9bdbd80f4554eb6017712fed245382ef',
      'native_key' => 'OnUserGroupSave',
      'filename' => 'modEvent/288104ff2cc197564ac19f02eab55a37.vehicle',
    ),
    66 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a7e2b320a678f498d55f3fe99da71fcf',
      'native_key' => 'OnUserGroupBeforeRemove',
      'filename' => 'modEvent/31c1f5fd271e9cc8035caaf6bb72cbe3.vehicle',
    ),
    67 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5c960428e5bb0d11f3becb900c36ce11',
      'native_key' => 'OnUserGroupRemove',
      'filename' => 'modEvent/19f774dfd9f8787e29b0b0ea37a7acb7.vehicle',
    ),
    68 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa6ff637cc7f0935e696d2a41ab4d13f',
      'native_key' => 'OnBeforeUserGroupFormSave',
      'filename' => 'modEvent/57fee41461a396c7f717eacf9ba2562f.vehicle',
    ),
    69 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6adca6623e039e3e11498257591bfb62',
      'native_key' => 'OnUserGroupFormSave',
      'filename' => 'modEvent/b6e6dd61cc6e7429153292599a017e63.vehicle',
    ),
    70 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '652bcc1bde9bf12daf5aa14ee650e178',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/0ac2203410567e47fb1c3c1fdd991ff9.vehicle',
    ),
    71 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'dbe73f9c3fa62b96d7dee70ac0d50d9d',
      'native_key' => 'OnBeforeUserGroupFormRemove',
      'filename' => 'modEvent/8b8db2ccbe7594a999726259d817635f.vehicle',
    ),
    72 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5f45ac34a2b005bda6a927a1e808a67a',
      'native_key' => 'OnDocFormPrerender',
      'filename' => 'modEvent/4facb2c8717e4d630f44e4d32c0dc144.vehicle',
    ),
    73 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6d0efb97ef30e85086717822bcd1ab2',
      'native_key' => 'OnDocFormRender',
      'filename' => 'modEvent/abf4f680d06717fad36c0f97dffaee18.vehicle',
    ),
    74 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c8bb171c61b98c51f4df457635d0819',
      'native_key' => 'OnBeforeDocFormSave',
      'filename' => 'modEvent/1f7a6f5d791f6a43513395d38d910e3d.vehicle',
    ),
    75 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b9a35b197d290ad8fd59be32b06197f8',
      'native_key' => 'OnDocFormSave',
      'filename' => 'modEvent/faf791a92129c83b5b0a086743c491f8.vehicle',
    ),
    76 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9b90ae6255d213fc956a7065bcc021f5',
      'native_key' => 'OnBeforeDocFormDelete',
      'filename' => 'modEvent/18895dceaee4917f8bbee00401b73e7d.vehicle',
    ),
    77 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1146580741c82c46a6eac9e85e1411bf',
      'native_key' => 'OnDocFormDelete',
      'filename' => 'modEvent/6acc032cf38826e902d5339837483015.vehicle',
    ),
    78 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5ee9152a7c1be5941b0ba8aeae747d4',
      'native_key' => 'OnDocPublished',
      'filename' => 'modEvent/a7b0b507bcb9355cf4263944f11ff5c1.vehicle',
    ),
    79 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '81a5be73cad6342ea2779138c2703363',
      'native_key' => 'OnDocUnPublished',
      'filename' => 'modEvent/bd7ac3bb959bf3bb9e0127d03e348b08.vehicle',
    ),
    80 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79f98d48f0e683b34628543b3a5924ba',
      'native_key' => 'OnBeforeEmptyTrash',
      'filename' => 'modEvent/73fc7737eb43e92869e8909509a3a354.vehicle',
    ),
    81 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c6f985823a0bd8188c70aead26d645f',
      'native_key' => 'OnEmptyTrash',
      'filename' => 'modEvent/2a87cb8d985e3d240e05153b9f8858f4.vehicle',
    ),
    82 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40dd694ccc1ebddc2acdc872d2e9f2bc',
      'native_key' => 'OnResourceTVFormPrerender',
      'filename' => 'modEvent/767daf4715f881da8919a70aaa1bafa8.vehicle',
    ),
    83 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0f0ec99d3509e6d040882a8becd07ca0',
      'native_key' => 'OnResourceTVFormRender',
      'filename' => 'modEvent/f25bbfdea824901fe9c6c82f5bf95dce.vehicle',
    ),
    84 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '24241e5b0196c1b581d550abbb7039f5',
      'native_key' => 'OnResourceAutoPublish',
      'filename' => 'modEvent/b3281b25456db1ecf7865582cfad46c4.vehicle',
    ),
    85 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9ba1d263a982292bc070546b61d28580',
      'native_key' => 'OnResourceDelete',
      'filename' => 'modEvent/3d9e40a9c920964711cf1b49d92159ba.vehicle',
    ),
    86 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5398c2954774b3dc3b88bebf3c7b041e',
      'native_key' => 'OnResourceUndelete',
      'filename' => 'modEvent/3c91f2e7c40f9ad36b05370806c2b8a8.vehicle',
    ),
    87 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6d4c1fa95815d454761662212d0f7968',
      'native_key' => 'OnResourceBeforeSort',
      'filename' => 'modEvent/745acf89a87b86cb958fb99869793904.vehicle',
    ),
    88 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbc14013fa5021a08c7467bf4f2c3e86',
      'native_key' => 'OnResourceSort',
      'filename' => 'modEvent/7a55e8abbf2b55a806bcc25d0667a1f3.vehicle',
    ),
    89 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ec098ffc35c0b7ced0c896809bd1469',
      'native_key' => 'OnResourceDuplicate',
      'filename' => 'modEvent/4ecc853dce6f3aee0dc18b1a6a663bf4.vehicle',
    ),
    90 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '500553356860dc6035a947b5cfedecb9',
      'native_key' => 'OnResourceToolbarLoad',
      'filename' => 'modEvent/925d0f156a8be2f4b59b5b62ae915b09.vehicle',
    ),
    91 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '46ad1a07dd73367d66f5bda908983f07',
      'native_key' => 'OnResourceRemoveFromResourceGroup',
      'filename' => 'modEvent/69383a4855851399cb73a2deee87655c.vehicle',
    ),
    92 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c87545a5c6d53a5d70c181e76aa05f0',
      'native_key' => 'OnResourceAddToResourceGroup',
      'filename' => 'modEvent/54fc91aebfee0bd3506e1c1f2102849e.vehicle',
    ),
    93 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '00f8b9bacae0563600434c5389c23f02',
      'native_key' => 'OnRichTextEditorRegister',
      'filename' => 'modEvent/39be16e6d3a632eb45047cc8cc7c7f89.vehicle',
    ),
    94 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c84dfaddcb8f0ce854503458e4b4dfa3',
      'native_key' => 'OnRichTextEditorInit',
      'filename' => 'modEvent/efca8c43cab587ce6453e1b11fbf1484.vehicle',
    ),
    95 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '70ef265f06896e06a7ba2a95af55e74f',
      'native_key' => 'OnRichTextBrowserInit',
      'filename' => 'modEvent/431d2aa4b2f772cec67278132dfe830c.vehicle',
    ),
    96 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3d283c4a743f21c84affcac642974ff7',
      'native_key' => 'OnWebLogin',
      'filename' => 'modEvent/8c370dfe87b866acadd841650a352bef.vehicle',
    ),
    97 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '07e941fc290840abe232c63c6dda3238',
      'native_key' => 'OnBeforeWebLogout',
      'filename' => 'modEvent/1a03c0efaac9197fb1b567b36b4abf5f.vehicle',
    ),
    98 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0d42e5630cf87634250f79e75cfb997b',
      'native_key' => 'OnWebLogout',
      'filename' => 'modEvent/16fa1f359d2ce89a0e85b5074a3c2779.vehicle',
    ),
    99 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ecbaab74829862d64384a200552b3700',
      'native_key' => 'OnManagerLogin',
      'filename' => 'modEvent/c42186ae95f5a06a2fedc636935bb93b.vehicle',
    ),
    100 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5ba0e5574bb3caa45b42129555b4792',
      'native_key' => 'OnBeforeManagerLogout',
      'filename' => 'modEvent/fefe94b68f52e97a9619db2a667b48bb.vehicle',
    ),
    101 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd5413c3ec19820c84acafd773565d4cf',
      'native_key' => 'OnManagerLogout',
      'filename' => 'modEvent/bc0f08af444be998fa9a11f0e9e57568.vehicle',
    ),
    102 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '931ad096c6e1fca27f57853e603b7c09',
      'native_key' => 'OnBeforeWebLogin',
      'filename' => 'modEvent/172cb7f59cf44fe98520b93a9fc9d6f2.vehicle',
    ),
    103 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5968dc5061ad8f9fe5ac6e95fb118d59',
      'native_key' => 'OnWebAuthentication',
      'filename' => 'modEvent/56e2a579adfd6a0b0833b21729fc0d84.vehicle',
    ),
    104 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cbda73bbb3e194196fd06464aaf6592',
      'native_key' => 'OnBeforeManagerLogin',
      'filename' => 'modEvent/6f76527f7351a15f9c000a4af11c576b.vehicle',
    ),
    105 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7f2ac79578895b9807aec4188db926b4',
      'native_key' => 'OnManagerAuthentication',
      'filename' => 'modEvent/ebb53b737d30fbc1d35e2f5d8d9038c8.vehicle',
    ),
    106 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3f04a6579d3a3dcc3785f2903290818d',
      'native_key' => 'OnManagerLoginFormRender',
      'filename' => 'modEvent/1c39826e3d1b29793c5a4f0bfde913d6.vehicle',
    ),
    107 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea57fcb97c6b6425a5147e025f8df610',
      'native_key' => 'OnManagerLoginFormPrerender',
      'filename' => 'modEvent/3c0c3fae4367ef431a140f602fd4e5ea.vehicle',
    ),
    108 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd1144eca4defcf69f6ecfcc375ee687a',
      'native_key' => 'OnPageUnauthorized',
      'filename' => 'modEvent/ab644d0b3207e924aab973c85bf4005f.vehicle',
    ),
    109 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0e54664df45f714767823a07962feec9',
      'native_key' => 'OnUserFormPrerender',
      'filename' => 'modEvent/f56186f096f6c0a3b7bcfb8573ab9883.vehicle',
    ),
    110 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '56359a658a6679737a88c31181990e40',
      'native_key' => 'OnUserFormRender',
      'filename' => 'modEvent/378f6f9fde88ab1e1ad53140e5911245.vehicle',
    ),
    111 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40abaafd296218e1e227177c11688951',
      'native_key' => 'OnBeforeUserFormSave',
      'filename' => 'modEvent/7a9505981bb434e051789c6a44e7c64b.vehicle',
    ),
    112 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '6ceb46737df50ef3d71fca0edef59a38',
      'native_key' => 'OnUserFormSave',
      'filename' => 'modEvent/5f19fa5d9fc65cd976af9d026cf25893.vehicle',
    ),
    113 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '777c55a888683a9694b2e78f9f7cd69d',
      'native_key' => 'OnBeforeUserFormDelete',
      'filename' => 'modEvent/62135f1fe37a68ddc62cb554ba814bb3.vehicle',
    ),
    114 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c3600527e9a3f4d8cd3cc3de210ec2e5',
      'native_key' => 'OnUserFormDelete',
      'filename' => 'modEvent/b072a6cb64703dde5452d63e8460afab.vehicle',
    ),
    115 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0dab502b3da7e4afa1af3cbe9d58faf2',
      'native_key' => 'OnUserNotFound',
      'filename' => 'modEvent/e5ea34ccaacf98f951cda0476e4eb8ff.vehicle',
    ),
    116 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'de2f1bc9d888c1178ac3e813c9655de4',
      'native_key' => 'OnBeforeUserActivate',
      'filename' => 'modEvent/0f8ef38bd3ac8d5c8d15436cf8da487e.vehicle',
    ),
    117 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fd157568e82be23417740c8009862f33',
      'native_key' => 'OnUserActivate',
      'filename' => 'modEvent/24b53b81fe91286114f432778bade6be.vehicle',
    ),
    118 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e802545aa44c808f34643e4be6a7b694',
      'native_key' => 'OnBeforeUserDeactivate',
      'filename' => 'modEvent/f324175d256ed77f288e3d25c38e4e1b.vehicle',
    ),
    119 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8a241abeb88a42aa31a998e41345e87',
      'native_key' => 'OnUserDeactivate',
      'filename' => 'modEvent/f45c43efa830de87a6ba4bf3cc04d4c9.vehicle',
    ),
    120 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '206343961d91f3d71347fe05e8746f0b',
      'native_key' => 'OnBeforeUserDuplicate',
      'filename' => 'modEvent/816782250ae0983eb623db1cae09fb13.vehicle',
    ),
    121 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c5b5dbd85853645d06d2afb74e826c04',
      'native_key' => 'OnUserDuplicate',
      'filename' => 'modEvent/704f5b53d0c3fa75988aaf98779e94a7.vehicle',
    ),
    122 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c8fa324a301da9f0802980d62dd20e5d',
      'native_key' => 'OnUserChangePassword',
      'filename' => 'modEvent/98904f1eedd698ae8749f3e3cfbec964.vehicle',
    ),
    123 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '677d9b61366bcb729cf4369b13604184',
      'native_key' => 'OnUserBeforeRemove',
      'filename' => 'modEvent/e7f097b2c58590a821fdebeda1c63ebd.vehicle',
    ),
    124 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0a64a4d86c4298db7a7744384c79485',
      'native_key' => 'OnUserBeforeSave',
      'filename' => 'modEvent/a571e25da39fe806a1208c6ea0f13194.vehicle',
    ),
    125 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'eef75b9c07ad0e4dc65db77c7ddc3b89',
      'native_key' => 'OnUserSave',
      'filename' => 'modEvent/a70fdc1b567f487833a85c96ada6cb01.vehicle',
    ),
    126 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '40b244bbf18a106110f7e35d23c9ff04',
      'native_key' => 'OnUserRemove',
      'filename' => 'modEvent/0c1f508d7f71eb17bfc8638758d8d330.vehicle',
    ),
    127 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ba9c30bec5ebe9ec90313299a53db27b',
      'native_key' => 'OnUserBeforeAddToGroup',
      'filename' => 'modEvent/979c20ec610dd6a777fdb8a6a2cdb7bc.vehicle',
    ),
    128 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c0d707f1324f04444aacea940124d285',
      'native_key' => 'OnUserAddToGroup',
      'filename' => 'modEvent/7893d800dad1182fe177d2a30afed7ce.vehicle',
    ),
    129 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4e5bf42c0f8f5f91170da837dd9c17a8',
      'native_key' => 'OnUserBeforeRemoveFromGroup',
      'filename' => 'modEvent/391cbc8243673d78f826074d160fc4a2.vehicle',
    ),
    130 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a91498fe8baa370e1522ba919850efea',
      'native_key' => 'OnUserRemoveFromGroup',
      'filename' => 'modEvent/aef6acd571667d4f5dfbfee68189ce23.vehicle',
    ),
    131 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c5363d43f383724e1283b06905d71ea',
      'native_key' => 'OnWebPagePrerender',
      'filename' => 'modEvent/5b6a6ca1548687b16e148d377a6ea071.vehicle',
    ),
    132 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1adb31990fe36e8688c4e56d0825316d',
      'native_key' => 'OnBeforeCacheUpdate',
      'filename' => 'modEvent/8b142fec69656d2d6d48dc0e055ed392.vehicle',
    ),
    133 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5363407292da6491fdf07dd2deb10a14',
      'native_key' => 'OnCacheUpdate',
      'filename' => 'modEvent/92abf53d2998217f4e6ce155f73e90b8.vehicle',
    ),
    134 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ed7cbdda07c7e7fbafa8cb332c76b1e7',
      'native_key' => 'OnLoadWebPageCache',
      'filename' => 'modEvent/1764fa156c526c1e640e0f9bfb78a0e9.vehicle',
    ),
    135 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '05af12063bfc0f8540df8f4ca6913c16',
      'native_key' => 'OnBeforeSaveWebPageCache',
      'filename' => 'modEvent/52db7f773b97817933e8a3719a390a86.vehicle',
    ),
    136 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'feeeabfd68e7e3617bbaafa959149ce6',
      'native_key' => 'OnSiteRefresh',
      'filename' => 'modEvent/1d22aded6ce4accc3afd245639578f8c.vehicle',
    ),
    137 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '590d266f1eb17b352f099bf001aff73e',
      'native_key' => 'OnFileManagerDirCreate',
      'filename' => 'modEvent/e017bf2d007e6d97f4e5336fe730c889.vehicle',
    ),
    138 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '93062a164d08027169d634079af68399',
      'native_key' => 'OnFileManagerDirRemove',
      'filename' => 'modEvent/c8293312b6f1729244484d169f389b91.vehicle',
    ),
    139 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd387c9d98d39ce328dc67a39d638b1ec',
      'native_key' => 'OnFileManagerDirRename',
      'filename' => 'modEvent/dcba962998b24bd10bbfc6545ad5a9a4.vehicle',
    ),
    140 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1345daa3f7ac1ab1999e908a0e61ab29',
      'native_key' => 'OnFileManagerFileRename',
      'filename' => 'modEvent/b597f3762a5fbc1265a4c5154f475996.vehicle',
    ),
    141 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ebd881b9abd2c7c689e282c9d0380e90',
      'native_key' => 'OnFileManagerFileRemove',
      'filename' => 'modEvent/3c0dbdc833e15bcb3300ebdef24d0742.vehicle',
    ),
    142 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '79df54c6ec50a2d6b51a14ab219c3fa8',
      'native_key' => 'OnFileManagerFileUpdate',
      'filename' => 'modEvent/76936042d33ca43cefa3d4b0c25ae7f0.vehicle',
    ),
    143 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '102608bb43fc14639d6316f74ddb3d6c',
      'native_key' => 'OnFileManagerFileCreate',
      'filename' => 'modEvent/d6c2e3713fde193f7135e5c7f0235a8c.vehicle',
    ),
    144 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7a20837e356b1f752f060ac96a6530b',
      'native_key' => 'OnFileManagerBeforeUpload',
      'filename' => 'modEvent/7574b9299229f1e25c0075dea887c9fc.vehicle',
    ),
    145 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'aa268261685604d59c7df445588c070a',
      'native_key' => 'OnFileManagerUpload',
      'filename' => 'modEvent/fdd7c93299918c87cd92d4d3a56847e5.vehicle',
    ),
    146 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '99d38c810a0dff69c791e572db0020a5',
      'native_key' => 'OnFileManagerMoveObject',
      'filename' => 'modEvent/79e63973e17fd08de6c61a4ce754a748.vehicle',
    ),
    147 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2deed522b3beb8dcd7a86f411029497b',
      'native_key' => 'OnFileCreateFormPrerender',
      'filename' => 'modEvent/39f444c27070fef0b4b976ece161d747.vehicle',
    ),
    148 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '798dc0445dd3c7a0e438f90d53912d53',
      'native_key' => 'OnFileEditFormPrerender',
      'filename' => 'modEvent/5ec8341e0b75ca6d6a7e48ba3ce7dc8a.vehicle',
    ),
    149 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ffe793fe227c453ea31cee318a912dc2',
      'native_key' => 'OnManagerPageInit',
      'filename' => 'modEvent/8f3f1c5527c49e7ba735d8bc2fdce007.vehicle',
    ),
    150 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7be1cb2f1cbe03c8bee663f54689be2d',
      'native_key' => 'OnManagerPageBeforeRender',
      'filename' => 'modEvent/f0773d8ce091c3551cc65603114af68e.vehicle',
    ),
    151 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '97eac550890a57de21e5511fa95a1c6d',
      'native_key' => 'OnManagerPageAfterRender',
      'filename' => 'modEvent/6da83bf84e25a07815523f3ebf2124ca.vehicle',
    ),
    152 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '30dc270c8ff438bdd3fb77d912f3478e',
      'native_key' => 'OnWebPageInit',
      'filename' => 'modEvent/c02d56a847801540d96674aa3085e98d.vehicle',
    ),
    153 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '8eb3d07ca94e52e28fe8b53e6d74d6b4',
      'native_key' => 'OnLoadWebDocument',
      'filename' => 'modEvent/32ab9717ac05d0ab825fe6585e53401a.vehicle',
    ),
    154 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '3e7450afcbc7bee97ea8a979b21eb4a9',
      'native_key' => 'OnParseDocument',
      'filename' => 'modEvent/5315f7f64052505f5eab0fe291717340.vehicle',
    ),
    155 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2c2eb2987acf30bca7e7fe01ad6380d2',
      'native_key' => 'OnWebPageComplete',
      'filename' => 'modEvent/054266c9712c7bb7c0e58b388a9d0970.vehicle',
    ),
    156 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ce11cd61adf0baa1135e16510f1f499c',
      'native_key' => 'OnBeforeManagerPageInit',
      'filename' => 'modEvent/e1196dc2a38229094d5cc4892dd102e1.vehicle',
    ),
    157 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1a309d7e6f70696fce0f597671a77668',
      'native_key' => 'OnPageNotFound',
      'filename' => 'modEvent/1ffec682d3b01f6230855c7e5d7bcd9f.vehicle',
    ),
    158 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a53fd2d9f77cae6757f45a73bc087cb0',
      'native_key' => 'OnHandleRequest',
      'filename' => 'modEvent/a2ad03455b434b136379fbdb3e66716d.vehicle',
    ),
    159 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'f368c71db671ae8451cec32bdf60a80e',
      'native_key' => 'OnMODXInit',
      'filename' => 'modEvent/865287427a4963c6234cb3ce70d170af.vehicle',
    ),
    160 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e306aa2af7f682624caeeb1d4ffc9302',
      'native_key' => 'OnElementNotFound',
      'filename' => 'modEvent/33f2699d8058acf209c3076edee4650f.vehicle',
    ),
    161 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4a8fd03ec134820553bb3167f9b686dd',
      'native_key' => 'OnSiteSettingsRender',
      'filename' => 'modEvent/1c00473c61e1fbc629be70ba4146e677.vehicle',
    ),
    162 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1df5eecbb16e10f8b14c3dea37e4fc85',
      'native_key' => 'OnInitCulture',
      'filename' => 'modEvent/7caf75e9345bb368d2e204177bc4ef23.vehicle',
    ),
    163 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5a7868e9e9b1d388d5eb96a167e41065',
      'native_key' => 'OnCategorySave',
      'filename' => 'modEvent/918ffa2be50c0339ea67c16065c3545e.vehicle',
    ),
    164 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c4702cfbd16809efa9da7808b12af0df',
      'native_key' => 'OnCategoryBeforeSave',
      'filename' => 'modEvent/ad904ce167c9c7b94d9c7ba858afbba3.vehicle',
    ),
    165 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'bc579c27f2bb1e14a11b94be8ac94748',
      'native_key' => 'OnCategoryRemove',
      'filename' => 'modEvent/e891230c8482ff38fd7cbe5a4be5f34d.vehicle',
    ),
    166 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd35f486472c835057c5b858198e1658',
      'native_key' => 'OnCategoryBeforeRemove',
      'filename' => 'modEvent/c6726ff840a2e48411400ac6aaa19af7.vehicle',
    ),
    167 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '853d7c35346a5a15212b0c8934d4461b',
      'native_key' => 'OnChunkSave',
      'filename' => 'modEvent/b1e19f10f3b3c03f7186b787e8d5bdc7.vehicle',
    ),
    168 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '20330c15735e3aeac078682878fec023',
      'native_key' => 'OnChunkBeforeSave',
      'filename' => 'modEvent/0a89258f84a0a6361b6ffba69f654ce5.vehicle',
    ),
    169 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9476298a51bbd81d3238b7ac7562b55a',
      'native_key' => 'OnChunkRemove',
      'filename' => 'modEvent/e48e49508f171f541e25b5ba06fa5058.vehicle',
    ),
    170 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'b766467d0c17f44e4a6ad8fb4f1a1316',
      'native_key' => 'OnChunkBeforeRemove',
      'filename' => 'modEvent/8e7197d9673cf88e886dfe48f2724b46.vehicle',
    ),
    171 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9bb1fe47b3cd42c05eb221103513d15',
      'native_key' => 'OnChunkFormPrerender',
      'filename' => 'modEvent/5a9364165c5beeb7ef3c16ab6a0a3808.vehicle',
    ),
    172 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f90bc47a92a8e9ca47adadd0ba01cb0',
      'native_key' => 'OnChunkFormRender',
      'filename' => 'modEvent/6f7dee1fb11a721db409ba4696f13e55.vehicle',
    ),
    173 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '894a5be8536f117ea8b2efb48a1e1ded',
      'native_key' => 'OnBeforeChunkFormSave',
      'filename' => 'modEvent/1fb326a1a9fcb20d3cb804d2f3a32348.vehicle',
    ),
    174 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '4c15afea757aee4d70fd452fd8f8e962',
      'native_key' => 'OnChunkFormSave',
      'filename' => 'modEvent/4d98fe0e77fc3c3a7960dfabe4c6bb36.vehicle',
    ),
    175 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'e86bc895c685812174f53b5d4842ec9b',
      'native_key' => 'OnBeforeChunkFormDelete',
      'filename' => 'modEvent/c51271ae566270d23d9308ed013c2220.vehicle',
    ),
    176 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd107dc4718760bb3f7798627289e868f',
      'native_key' => 'OnChunkFormDelete',
      'filename' => 'modEvent/b0e52ec1372e00763ad3c48f942ae652.vehicle',
    ),
    177 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '65368a0f09a12d045f7e172eda21d399',
      'native_key' => 'OnContextSave',
      'filename' => 'modEvent/232d918546342fb72dfc02b64191df36.vehicle',
    ),
    178 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ea53ff3c5e78e30f59166e88d99b90d7',
      'native_key' => 'OnContextBeforeSave',
      'filename' => 'modEvent/354ddc98bf406c2d0a9c745cb3a27ac9.vehicle',
    ),
    179 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd2393e33ade2f1a24830575ecf4c46a6',
      'native_key' => 'OnContextRemove',
      'filename' => 'modEvent/4b409f9fdaa6f7d62573742cb04dd5de.vehicle',
    ),
    180 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fbf87a557ff6a2ff18d3d7d7e043ff2f',
      'native_key' => 'OnContextBeforeRemove',
      'filename' => 'modEvent/e2182fe31ea51c5e71286ef0acc24050.vehicle',
    ),
    181 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c6d2be49ae85c8f52cc4782f8a1b8802',
      'native_key' => 'OnContextFormPrerender',
      'filename' => 'modEvent/a8dd1327fdd11f8fca1a2dbd7f3fc1d0.vehicle',
    ),
    182 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '5b89c900bf33c7fcca1193527063413b',
      'native_key' => 'OnContextFormRender',
      'filename' => 'modEvent/c5575f8a9099d8a1ee0554e6d82831e6.vehicle',
    ),
    183 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2d64512af30378c0d4f6e85c395276b5',
      'native_key' => 'OnPluginSave',
      'filename' => 'modEvent/9ac8285c32c0eb68aa655a2fdcf78a8b.vehicle',
    ),
    184 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'a9083d43b493751a75d3798b827602d8',
      'native_key' => 'OnPluginBeforeSave',
      'filename' => 'modEvent/7b8ad28bffb87cb672b0716778ef5c2c.vehicle',
    ),
    185 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'fdd4ca44805ebca9d74ab27ceeb8d59c',
      'native_key' => 'OnPluginRemove',
      'filename' => 'modEvent/16c3538b31d57bfa7163a56be2bcdc05.vehicle',
    ),
    186 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ccb20305c70437f4fcd44d48916b74fd',
      'native_key' => 'OnPluginBeforeRemove',
      'filename' => 'modEvent/4861679095a87ca14124a01a5068c3ac.vehicle',
    ),
    187 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c9c5d0089af83e2189d03d8fcdb3d382',
      'native_key' => 'OnPluginFormPrerender',
      'filename' => 'modEvent/4bdb1e20e9bcde49e68df972d8a67102.vehicle',
    ),
    188 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '41b6707f24308ba41add65f10bace384',
      'native_key' => 'OnPluginFormRender',
      'filename' => 'modEvent/512b51966d46addc0d28a62bfe08ae0f.vehicle',
    ),
    189 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '7cd45f19765ba7a80d886431ee0df4c9',
      'native_key' => 'OnBeforePluginFormSave',
      'filename' => 'modEvent/f8948963938a8e8c7c367c8d8d3f0115.vehicle',
    ),
    190 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '1f592bf5e8f2c32ba43e5779c19d714b',
      'native_key' => 'OnPluginFormSave',
      'filename' => 'modEvent/8cf05fd180e61c4d5b56d94f86f666de.vehicle',
    ),
    191 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '844a8fd9430eefe5d31d05ab3ec7b125',
      'native_key' => 'OnBeforePluginFormDelete',
      'filename' => 'modEvent/b70eed8ada23186f8a32d0820ab90b64.vehicle',
    ),
    192 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'ff1e13968011ebc76453998b087c36ba',
      'native_key' => 'OnPluginFormDelete',
      'filename' => 'modEvent/aa4577d0cdfe9375b75c67beab6de253.vehicle',
    ),
    193 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'c7e50501481aea8db2fafa5ff3963214',
      'native_key' => 'OnPropertySetSave',
      'filename' => 'modEvent/308429e0a8d9af33b83770fa9260a00c.vehicle',
    ),
    194 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '9d20d10e507cd0ea462281126b4e3168',
      'native_key' => 'OnPropertySetBeforeSave',
      'filename' => 'modEvent/0c335a5c6a7614b1ef6f43d5c297a503.vehicle',
    ),
    195 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '0c16cec83de5bb2cde946d655b1a22f4',
      'native_key' => 'OnPropertySetRemove',
      'filename' => 'modEvent/d96f127dce23edfe5b5e85e5aed1f226.vehicle',
    ),
    196 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '17467ae6dd4730d556c3ca3c04825c99',
      'native_key' => 'OnPropertySetBeforeRemove',
      'filename' => 'modEvent/a2d28fdc63b3bf7602d5b791c3a1a5ec.vehicle',
    ),
    197 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd6ddd5040ee1178fa7cb22d0dc0640ee',
      'native_key' => 'OnMediaSourceBeforeFormDelete',
      'filename' => 'modEvent/bc3d62fa0aa06c86119e259a5cc32151.vehicle',
    ),
    198 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '245749157b13d62d37622c5e589a62d9',
      'native_key' => 'OnMediaSourceBeforeFormSave',
      'filename' => 'modEvent/be99e204de8f0011ad88fb1e6b274cf5.vehicle',
    ),
    199 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => '2b7330fabf9565045d7273c293c518b8',
      'native_key' => 'OnMediaSourceGetProperties',
      'filename' => 'modEvent/ee35cacbb6c099747b8bb87739d28642.vehicle',
    ),
    200 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd28728520e55b9cf10c80880072d3e8e',
      'native_key' => 'OnMediaSourceFormDelete',
      'filename' => 'modEvent/0e29069dc6db568eaa89d29fb37ccb47.vehicle',
    ),
    201 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'cd6be6aee92c3b6925de92040e2b1a8a',
      'native_key' => 'OnMediaSourceFormSave',
      'filename' => 'modEvent/4c9883114555fa418e049856069aa7bd.vehicle',
    ),
    202 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modEvent',
      'guid' => 'd25c79d0590c26234417778b7f0b3183',
      'native_key' => 'OnMediaSourceDuplicate',
      'filename' => 'modEvent/e259a4ada699416782145873315850a0.vehicle',
    ),
    203 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '70376b21824125d0d9afcef45fe4c47e',
      'native_key' => 'access_category_enabled',
      'filename' => 'modSystemSetting/8d1c283a77203142cf007e8aa6fd9106.vehicle',
    ),
    204 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '30a1fd518cdea93a944e91c5d8e45eaf',
      'native_key' => 'access_context_enabled',
      'filename' => 'modSystemSetting/47d7ff446c5a72357bce6a7868a61a10.vehicle',
    ),
    205 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cf3a08edd324989b4bdc59184c7d2f2a',
      'native_key' => 'access_resource_group_enabled',
      'filename' => 'modSystemSetting/c163ec49ffa4a20b4b7c0fb18f5b5658.vehicle',
    ),
    206 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14fe7be043ccb6ff00772d8f162b868d',
      'native_key' => 'allow_forward_across_contexts',
      'filename' => 'modSystemSetting/9a085d1fd9c550f3b35e73e95b1ae74d.vehicle',
    ),
    207 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49d8c410204b03c7bf0763f51bbcda78',
      'native_key' => 'allow_manager_login_forgot_password',
      'filename' => 'modSystemSetting/ecd122cd1fc33028baf2b6ef66957868.vehicle',
    ),
    208 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4141d24d1201db1c0fe5d58f39e93966',
      'native_key' => 'allow_multiple_emails',
      'filename' => 'modSystemSetting/7c8932f74ce6515e1971b9a45a32dfa4.vehicle',
    ),
    209 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad2c21092333450f7196ebe6f78a683b',
      'native_key' => 'allow_tags_in_post',
      'filename' => 'modSystemSetting/91175f602e4bfa91536d58c504aa15d7.vehicle',
    ),
    210 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '823080b93113c6e0b773e15d6f0ad340',
      'native_key' => 'archive_with',
      'filename' => 'modSystemSetting/45be4aaafd2367298645ab478229da5b.vehicle',
    ),
    211 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2332d91606d7c79148720ea35a9088cf',
      'native_key' => 'auto_menuindex',
      'filename' => 'modSystemSetting/8c9148500c8d119987e77a0cf73ed57e.vehicle',
    ),
    212 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4d926564717a4d05d3ffb89462480add',
      'native_key' => 'auto_check_pkg_updates',
      'filename' => 'modSystemSetting/9c9283bf070d0def62fdf48d53c71cc3.vehicle',
    ),
    213 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8e8302ff609d1e780fe5e08cd49561f9',
      'native_key' => 'auto_check_pkg_updates_cache_expire',
      'filename' => 'modSystemSetting/e938e327a8d2999305a3b70baed37774.vehicle',
    ),
    214 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd3bb1b62551c9911a58d797178dbb782',
      'native_key' => 'automatic_alias',
      'filename' => 'modSystemSetting/d68d068bc60d23bdf7f1b1651df9674f.vehicle',
    ),
    215 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f05fbe3cd6169d3d690dfa451a73c0f',
      'native_key' => 'base_help_url',
      'filename' => 'modSystemSetting/6d1bbf8993c1dc919e20e7046ee02cb2.vehicle',
    ),
    216 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '63e7e69ee58af275640348d7f529df35',
      'native_key' => 'blocked_minutes',
      'filename' => 'modSystemSetting/305d53340147bd11859cbab605f19163.vehicle',
    ),
    217 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5d478e5ea3bfb7bcaddbeb203f798f54',
      'native_key' => 'cache_action_map',
      'filename' => 'modSystemSetting/4ab8a171aa57f43c8c0074186fb696ec.vehicle',
    ),
    218 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7fe8af184a745b6c790637990670967d',
      'native_key' => 'cache_alias_map',
      'filename' => 'modSystemSetting/5b23eeaf786fd82e475f63051428410f.vehicle',
    ),
    219 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '51cd3a93a1caf36afbfba8a39d8e9cf1',
      'native_key' => 'cache_context_settings',
      'filename' => 'modSystemSetting/d6d10591063d42f617a8e655c5d10ad2.vehicle',
    ),
    220 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '67697b7f6c70ecf913274392f441796b',
      'native_key' => 'cache_db',
      'filename' => 'modSystemSetting/8e41b6a036c762316ee5ae8e57ff6a9e.vehicle',
    ),
    221 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e3d9295922faadd41825d552b5c37a33',
      'native_key' => 'cache_db_expires',
      'filename' => 'modSystemSetting/23ae8248bb12d55b83b4c271c8b84acf.vehicle',
    ),
    222 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea7965bf1c676c0819717889b5af469a',
      'native_key' => 'cache_db_session',
      'filename' => 'modSystemSetting/3dc26653565be91b0c905d42792a8ead.vehicle',
    ),
    223 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f3429882640b346d414e6416cb3e05fe',
      'native_key' => 'cache_db_session_lifetime',
      'filename' => 'modSystemSetting/68ddb8a4dcbf2c1c38e16c2c40870ddf.vehicle',
    ),
    224 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '050f9c7fbc42ce9dc0896c7ef80f3895',
      'native_key' => 'cache_default',
      'filename' => 'modSystemSetting/5a285068a693af94ada608a76215de09.vehicle',
    ),
    225 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6628a377ef3227c21623121caf5c7e5f',
      'native_key' => 'cache_disabled',
      'filename' => 'modSystemSetting/66603f8448cb4dcdf124fd194b1302d6.vehicle',
    ),
    226 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'dd02b4b14a16f39fc51188eaffd230ad',
      'native_key' => 'cache_expires',
      'filename' => 'modSystemSetting/2a3d5d59d2545236f48a46635cfde51b.vehicle',
    ),
    227 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '21975bafa7f4382cd8b134da68ae8ba7',
      'native_key' => 'cache_format',
      'filename' => 'modSystemSetting/1a11ad51366daeafcfb0fcf820a366cc.vehicle',
    ),
    228 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '285ecaccadbbbbe9baac2a978f6807d2',
      'native_key' => 'cache_handler',
      'filename' => 'modSystemSetting/cbf559b3c77f39f7ad4a7d048d182d1e.vehicle',
    ),
    229 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '126713ff9d9f419188e3a1866da3490c',
      'native_key' => 'cache_lang_js',
      'filename' => 'modSystemSetting/59767e87b4d99651dff057e368f777e4.vehicle',
    ),
    230 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c1b74b831fbff2e4aa703a5e95bf4e35',
      'native_key' => 'cache_lexicon_topics',
      'filename' => 'modSystemSetting/02a38c56c79e5e24acc3592b57a1f762.vehicle',
    ),
    231 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82187e2c64cfe92fc5369a64a22f1e1b',
      'native_key' => 'cache_noncore_lexicon_topics',
      'filename' => 'modSystemSetting/5a8710437c9ed3bdb048bfe64bb9ad78.vehicle',
    ),
    232 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd6e3aebd571c841a09a2eb1b467e2686',
      'native_key' => 'cache_resource',
      'filename' => 'modSystemSetting/9b60f73cda0c1005da3a50d1b9522bc6.vehicle',
    ),
    233 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '086601d125fbc21ac7276f9cc3be950c',
      'native_key' => 'cache_resource_expires',
      'filename' => 'modSystemSetting/c21cc5cc12cab9a170f90b08cf4c6d80.vehicle',
    ),
    234 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '32b80147887ffbe6eba716c47cee22cf',
      'native_key' => 'cache_scripts',
      'filename' => 'modSystemSetting/ce666f70d84ecc225f6d05c0a6ce3372.vehicle',
    ),
    235 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c087117a3fd03459c695e530e2228601',
      'native_key' => 'cache_system_settings',
      'filename' => 'modSystemSetting/3c67abf30d50f46cc4b826ec4ee5342d.vehicle',
    ),
    236 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8265e27758bcf870dc4169d66fa94e92',
      'native_key' => 'clear_cache_refresh_trees',
      'filename' => 'modSystemSetting/353edc483215aedab7f0d09675976086.vehicle',
    ),
    237 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '92302a95cc8299fe5cc8df200a8e4be5',
      'native_key' => 'compress_css',
      'filename' => 'modSystemSetting/fbc68610c350f6de9854e68caa0467f7.vehicle',
    ),
    238 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '715a1e2b47296c828ee470237f09e60c',
      'native_key' => 'compress_js',
      'filename' => 'modSystemSetting/3d8e1597c3ee38e9ea1a63e93e28861e.vehicle',
    ),
    239 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1d8663b52f4505f84526975673dbeee7',
      'native_key' => 'compress_js_max_files',
      'filename' => 'modSystemSetting/15a29795c682569103d353634c26e71a.vehicle',
    ),
    240 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f8de7d0a5eca8d6fc160e028b73bbc5',
      'native_key' => 'compress_js_groups',
      'filename' => 'modSystemSetting/83076284fdb08490f7c4e8639de4efdc.vehicle',
    ),
    241 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aee7e0471f66bf5eb6d9f395cd460168',
      'native_key' => 'confirm_navigation',
      'filename' => 'modSystemSetting/b2ff9703c247ed32051bdf31e01a3083.vehicle',
    ),
    242 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab20a911b16f5657cfbb233c521d6c5d',
      'native_key' => 'container_suffix',
      'filename' => 'modSystemSetting/77341c739e56711d3e4c1ab8fa155a61.vehicle',
    ),
    243 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '03ed3a85031ddd2a296f915c841f22d3',
      'native_key' => 'context_tree_sort',
      'filename' => 'modSystemSetting/289e6915c3e2960f714a55cf59e59798.vehicle',
    ),
    244 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b60488265d647cae2085ecca3f5bc911',
      'native_key' => 'context_tree_sortby',
      'filename' => 'modSystemSetting/0473d27a16c174b22d688a7d70d7764f.vehicle',
    ),
    245 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0c8fa7450bd0c84e32dfe9785434434d',
      'native_key' => 'context_tree_sortdir',
      'filename' => 'modSystemSetting/27b431f3dc84a9e23c5f8cda44e13127.vehicle',
    ),
    246 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ad743d32d6997a5ce1fa63bdf0dbc75d',
      'native_key' => 'cultureKey',
      'filename' => 'modSystemSetting/c4de659d23ee79de502a6b2fcda4a244.vehicle',
    ),
    247 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2af97518d0572f52a77db658c35bf12c',
      'native_key' => 'date_timezone',
      'filename' => 'modSystemSetting/e14754d1b1262bdef0d641089b64f755.vehicle',
    ),
    248 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fd64f20fe7029579de97a1335a0e880f',
      'native_key' => 'debug',
      'filename' => 'modSystemSetting/8bd94c3e416e0f1c5858df25c00fe0c9.vehicle',
    ),
    249 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9a5e0f90f42a827d0dc0c6482d308e76',
      'native_key' => 'default_duplicate_publish_option',
      'filename' => 'modSystemSetting/59ad592680487bcdb147575574c90b56.vehicle',
    ),
    250 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '300a2fd7804d237e2eedef6be049d948',
      'native_key' => 'default_media_source',
      'filename' => 'modSystemSetting/d88febe4e0806669dbf769a62efcffce.vehicle',
    ),
    251 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78ed4c1d1cfd39147b0ac4035c62cfb8',
      'native_key' => 'default_per_page',
      'filename' => 'modSystemSetting/b22f71cabbdc8550ef13c4fa963efdca.vehicle',
    ),
    252 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3970c8d07cd7d046d5238ad0953a38a',
      'native_key' => 'default_context',
      'filename' => 'modSystemSetting/d447ed8890cb1a3de10c696de2cb2007.vehicle',
    ),
    253 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a4d7122104fbd864690f584d1a9fff22',
      'native_key' => 'default_template',
      'filename' => 'modSystemSetting/e0ed8bfbbe82201992e121e707da7966.vehicle',
    ),
    254 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '518aa94efcddc210d49fc37f22fa32d1',
      'native_key' => 'default_content_type',
      'filename' => 'modSystemSetting/e2a63a7f955f38613809f1e9d7695a6c.vehicle',
    ),
    255 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77ae0538b6cdb7baea12680af12649a2',
      'native_key' => 'editor_css_path',
      'filename' => 'modSystemSetting/84a396c23d7fa859fbac22f02a60cdb6.vehicle',
    ),
    256 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b6c6c40be1b209a647eb8d82c9a706bb',
      'native_key' => 'editor_css_selectors',
      'filename' => 'modSystemSetting/95c4df61fc831607fbb3e68243ea512b.vehicle',
    ),
    257 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca1244add10bd6c24d0d11d541f36576',
      'native_key' => 'emailsender',
      'filename' => 'modSystemSetting/6107cc797f1edfb6375f1f067036dd7f.vehicle',
    ),
    258 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b377436bf73d138a44843fe2de54d081',
      'native_key' => 'emailsubject',
      'filename' => 'modSystemSetting/e0f5abffebb3fc18d96463fc78fbf5a9.vehicle',
    ),
    259 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '07e336b129c832b86e4dc1c66f8b3335',
      'native_key' => 'enable_dragdrop',
      'filename' => 'modSystemSetting/16bcd78410ded57f0ab105b3763bfe33.vehicle',
    ),
    260 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e8d66f4ed8ecb397e7359e39a6fce33e',
      'native_key' => 'error_page',
      'filename' => 'modSystemSetting/02189dec2f59ed4b00ce2bd05a18edde.vehicle',
    ),
    261 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53ca60d52967b92a4ef0f0c6407228d0',
      'native_key' => 'failed_login_attempts',
      'filename' => 'modSystemSetting/f9cfa12b7b9a7aec73c4d277aa0594fe.vehicle',
    ),
    262 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5dada9a288d812114f098b211cb7a14e',
      'native_key' => 'fe_editor_lang',
      'filename' => 'modSystemSetting/be041b17ff311a1160718b6d3bbbf372.vehicle',
    ),
    263 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '429d034bbf5b99b57ed8e1098b78996b',
      'native_key' => 'feed_modx_news',
      'filename' => 'modSystemSetting/f81a662e17936eb97eac769581e416a2.vehicle',
    ),
    264 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1713c67733aad3ec7f0f64752470ca2a',
      'native_key' => 'feed_modx_news_enabled',
      'filename' => 'modSystemSetting/2f1a3b5667d097d0cc092f18e33c4ac1.vehicle',
    ),
    265 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '09a08234caf68a0ac48b76f3a48765fd',
      'native_key' => 'feed_modx_security',
      'filename' => 'modSystemSetting/71c71b9bc8a8db47fe452c3c0eea1e6f.vehicle',
    ),
    266 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '24b1766bc46630246ccf66f51ada6146',
      'native_key' => 'feed_modx_security_enabled',
      'filename' => 'modSystemSetting/9b912682e3fa09639686293428a49c46.vehicle',
    ),
    267 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a7cd7f8e3ce6fc16c142276b395e1dec',
      'native_key' => 'filemanager_path',
      'filename' => 'modSystemSetting/3badb0b0f52f4e2e765bcbd0a46f64d0.vehicle',
    ),
    268 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '875bfae18ecc7afdd5f1528d4d580368',
      'native_key' => 'filemanager_path_relative',
      'filename' => 'modSystemSetting/a4770b8dc56fc91adaead81559a215b3.vehicle',
    ),
    269 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8ffcb9de5f710eb0c23ff1241bbb017b',
      'native_key' => 'filemanager_url',
      'filename' => 'modSystemSetting/a35677e7267e8aaca8139a5d206136a0.vehicle',
    ),
    270 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6326158f6a37ed0e683e619441f6f0f8',
      'native_key' => 'filemanager_url_relative',
      'filename' => 'modSystemSetting/1f8ce5fdd0f776b11d2917cebee50ceb.vehicle',
    ),
    271 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ea5a2b6d28727a64ae9df2d395842174',
      'native_key' => 'forgot_login_email',
      'filename' => 'modSystemSetting/00609f66cd667dc722680d8b736c8b48.vehicle',
    ),
    272 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '93dde2159eb6861a8f6930cfb0709c35',
      'native_key' => 'form_customization_use_all_groups',
      'filename' => 'modSystemSetting/9f04a261e4f5ce62233c2c2542b29692.vehicle',
    ),
    273 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '34a84cef3a406fc609c8752d3a3a0a1f',
      'native_key' => 'forward_merge_excludes',
      'filename' => 'modSystemSetting/22aa69c167cfe4d6949342f5342cbfc0.vehicle',
    ),
    274 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b93012fb1558cee5521e6cea619692db',
      'native_key' => 'friendly_alias_lowercase_only',
      'filename' => 'modSystemSetting/f6d215e2d54c6b45d9ebc3d1cd97a146.vehicle',
    ),
    275 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5e196697377c2678f136b22ed076a176',
      'native_key' => 'friendly_alias_max_length',
      'filename' => 'modSystemSetting/bac4eb668d34f4060b3aea2b915ce1e1.vehicle',
    ),
    276 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3646872115ecfe4de29a2237a918a211',
      'native_key' => 'friendly_alias_restrict_chars',
      'filename' => 'modSystemSetting/b2d66ae3365d8947d7eef3be5bf720d5.vehicle',
    ),
    277 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e22f75abc32560dd58ada7bec941972a',
      'native_key' => 'friendly_alias_restrict_chars_pattern',
      'filename' => 'modSystemSetting/60a9a805d9115b8b2bebb3dc87f901ae.vehicle',
    ),
    278 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4c86aa2e30414fc03e3f8555f82f7cec',
      'native_key' => 'friendly_alias_strip_element_tags',
      'filename' => 'modSystemSetting/961e740787753ab793c98701fcf2be49.vehicle',
    ),
    279 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f92d87a3897649c7fbaabfe8249bdad0',
      'native_key' => 'friendly_alias_translit',
      'filename' => 'modSystemSetting/73bb272a7a836b9822075cee47752c5c.vehicle',
    ),
    280 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a945d8b18092b317912acd951d9e7bc8',
      'native_key' => 'friendly_alias_translit_class',
      'filename' => 'modSystemSetting/e0e2029f974e28ca3f325bfc9bc2e698.vehicle',
    ),
    281 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '49b79f8471fe48310bf0f576921c4d7a',
      'native_key' => 'friendly_alias_translit_class_path',
      'filename' => 'modSystemSetting/cbac608ab8c20ea90fcd10d2229a14dc.vehicle',
    ),
    282 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0a4653323e6232f851c8c3dc12e284b6',
      'native_key' => 'friendly_alias_trim_chars',
      'filename' => 'modSystemSetting/bf4df4be05a03f72e5b59b6814522aab.vehicle',
    ),
    283 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bfe22ab67a90c6e0c6d1b59a9237b3b8',
      'native_key' => 'friendly_alias_word_delimiter',
      'filename' => 'modSystemSetting/1f17d72ca79b02cca97b38725b56aeb4.vehicle',
    ),
    284 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bcd9479f4cb6891e7031842e6a422aa',
      'native_key' => 'friendly_alias_word_delimiters',
      'filename' => 'modSystemSetting/631687c215d2622490f70e07d5740e7d.vehicle',
    ),
    285 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72fa49c52af719a0235c9d9b2550ccdd',
      'native_key' => 'friendly_urls',
      'filename' => 'modSystemSetting/5f4651732c701bb905ca8155ab8ba288.vehicle',
    ),
    286 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0bd0b021cb4ebd8e047693b14f398909',
      'native_key' => 'friendly_urls_strict',
      'filename' => 'modSystemSetting/6f7c246b0c71e5c7e599b04a93d6bc5f.vehicle',
    ),
    287 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fda88f898b947e7a2a3c62a5f12733b0',
      'native_key' => 'global_duplicate_uri_check',
      'filename' => 'modSystemSetting/4219ce341b2b90ad6c4fd914a5be720d.vehicle',
    ),
    288 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ca9b0fc56d054ac77ae04daeda09ebf4',
      'native_key' => 'hidemenu_default',
      'filename' => 'modSystemSetting/78bec5b70f54df40fa9148454196f1c7.vehicle',
    ),
    289 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a21e02a916461958f7c921ae91302d44',
      'native_key' => 'inline_help',
      'filename' => 'modSystemSetting/8005dbc4d6d9f6e9c9392d88604278b0.vehicle',
    ),
    290 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a77e86c6d45d58208ebbb0fde2aa231c',
      'native_key' => 'locale',
      'filename' => 'modSystemSetting/e690ae723bb49b881bfd6c20786442ad.vehicle',
    ),
    291 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e2d2768fe283b0fc51ffec432f045d3e',
      'native_key' => 'log_level',
      'filename' => 'modSystemSetting/c79377f8652b80196740794ba36fbdca.vehicle',
    ),
    292 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7de21dabba697ad31001e6128c70bacb',
      'native_key' => 'log_target',
      'filename' => 'modSystemSetting/aa2fa1594c6d59c8e7dfbbe632962c3f.vehicle',
    ),
    293 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a15fe659b6c9dcbd16fbd9a4e8b321e4',
      'native_key' => 'link_tag_scheme',
      'filename' => 'modSystemSetting/3c2c3bacc4378ce813cae5d40f35ffd3.vehicle',
    ),
    294 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8cfb24d721d25118dda61664714498c3',
      'native_key' => 'lock_ttl',
      'filename' => 'modSystemSetting/cf0e1ae0402915e811908dce5e85b423.vehicle',
    ),
    295 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '512e14aa3aefd588c2959882bade0bd2',
      'native_key' => 'mail_charset',
      'filename' => 'modSystemSetting/f7598f252fddd8447b6d9b4d105c817b.vehicle',
    ),
    296 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd4beffaa909503fabc5e4efe69b95642',
      'native_key' => 'mail_encoding',
      'filename' => 'modSystemSetting/7ec08d340cfb91001e2700c6fd26cf54.vehicle',
    ),
    297 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3dfae8ea8284bde9d768e3b028efae93',
      'native_key' => 'mail_use_smtp',
      'filename' => 'modSystemSetting/fb583531e4a914b423bf3de15a5e34a5.vehicle',
    ),
    298 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '26fe0393a29b8b62e9b868e26db68c2b',
      'native_key' => 'mail_smtp_auth',
      'filename' => 'modSystemSetting/52e407fb65a4dd6a6b2a461f984dfb84.vehicle',
    ),
    299 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e0c49a9ab53a0c3af4e6dad9559ddba3',
      'native_key' => 'mail_smtp_helo',
      'filename' => 'modSystemSetting/037c791d3eb51c835ada4d067dcf6fae.vehicle',
    ),
    300 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '68c1d078f7e55b97629d275e44dafd89',
      'native_key' => 'mail_smtp_hosts',
      'filename' => 'modSystemSetting/5f0e80f0e43b2c58dd51c803323988b6.vehicle',
    ),
    301 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a5fbc4cc15e2b7400639e45c20ebfa11',
      'native_key' => 'mail_smtp_keepalive',
      'filename' => 'modSystemSetting/15d59a01632de4e47c0c4cc05a4695e4.vehicle',
    ),
    302 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '27192023e8893de194d2718ec5964654',
      'native_key' => 'mail_smtp_pass',
      'filename' => 'modSystemSetting/7a3a5c73f3cbbccd18b2a1a53f388aa6.vehicle',
    ),
    303 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f9b79f97016b0762f8bf2fbdb48637cd',
      'native_key' => 'mail_smtp_port',
      'filename' => 'modSystemSetting/64c66b5b37b40448e358f6ff6f66bc58.vehicle',
    ),
    304 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '87f2cd33c65accd69da56cb11d7411f0',
      'native_key' => 'mail_smtp_prefix',
      'filename' => 'modSystemSetting/2474bb8ac0304de8906c788be30d0b0d.vehicle',
    ),
    305 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '77a830e6393830ca9d3e07ae5515285c',
      'native_key' => 'mail_smtp_single_to',
      'filename' => 'modSystemSetting/146cfe7526f302c44a1d1a88bc177929.vehicle',
    ),
    306 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1b9403d2b90102f3da9c72410a439ca2',
      'native_key' => 'mail_smtp_timeout',
      'filename' => 'modSystemSetting/fbeea20978d73fdee15a1157f56512c3.vehicle',
    ),
    307 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5169935fb38bc3f3ea17de8b6c5b8aee',
      'native_key' => 'mail_smtp_user',
      'filename' => 'modSystemSetting/8d72480feeb17675d2bb4dbde5fe97f6.vehicle',
    ),
    308 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'becee5d025fb143abf4082fd9747e4ec',
      'native_key' => 'manager_date_format',
      'filename' => 'modSystemSetting/ff0c42d8feb09abd47bfeba3c7bffe38.vehicle',
    ),
    309 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '866919c4644078b3fff8976d97592210',
      'native_key' => 'manager_favicon_url',
      'filename' => 'modSystemSetting/3405e6778841d391a2e02b2ea190f3f8.vehicle',
    ),
    310 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ebe4f68f48065b83491f407cfddf6910',
      'native_key' => 'manager_html5_cache',
      'filename' => 'modSystemSetting/607b0aa87dc7f2fcdbd3c30c63bc0647.vehicle',
    ),
    311 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '35ad1225172e2811c1562a2b5d1183d5',
      'native_key' => 'manager_js_cache_file_locking',
      'filename' => 'modSystemSetting/263917a2460f4f086dc5a1f844fd6924.vehicle',
    ),
    312 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '47131998149ca024612d70d23ecf4271',
      'native_key' => 'manager_js_cache_max_age',
      'filename' => 'modSystemSetting/7b8cf793fb9323872249d9aa5c2e72bc.vehicle',
    ),
    313 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a1b12e7e59f43d4e3c7716f669156443',
      'native_key' => 'manager_js_document_root',
      'filename' => 'modSystemSetting/af0131354e98ce869d4a1f8e512ad89a.vehicle',
    ),
    314 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '989c80e5d0544c343455364ffb4b1473',
      'native_key' => 'manager_js_zlib_output_compression',
      'filename' => 'modSystemSetting/e79697848bdec263638b5c3d1a6a8be7.vehicle',
    ),
    315 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4e56962150305810715f1cf578d68300',
      'native_key' => 'manager_time_format',
      'filename' => 'modSystemSetting/2ad8ce7406fcd5955c3d974ed8f84b9e.vehicle',
    ),
    316 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '347641c68987bb12445f08990c48c373',
      'native_key' => 'manager_direction',
      'filename' => 'modSystemSetting/6a375959d43fd2f624b555fecb93a597.vehicle',
    ),
    317 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '74b2ae3615677442aba9be5308101e5c',
      'native_key' => 'manager_lang_attribute',
      'filename' => 'modSystemSetting/6ccdf0d2f714fab12d0341db77e08d46.vehicle',
    ),
    318 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '555aa0d87bfb3deed4a5d8215f82bf8d',
      'native_key' => 'manager_language',
      'filename' => 'modSystemSetting/08b5c7f759654290c7ed5adaca8a5e6e.vehicle',
    ),
    319 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5022aadd8a7b0a77875fb6b2ba8a8b80',
      'native_key' => 'manager_login_url_alternate',
      'filename' => 'modSystemSetting/84c914c59df5e05e17ac99795c50ded3.vehicle',
    ),
    320 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0970ca9d5a51564d179fd7827d0004f9',
      'native_key' => 'manager_theme',
      'filename' => 'modSystemSetting/c9c475dba5b914799e683e4035642170.vehicle',
    ),
    321 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c2d913b5e38956e330b286217dad8404',
      'native_key' => 'manager_week_start',
      'filename' => 'modSystemSetting/536dc3e73983317b2bcf5c5196ada506.vehicle',
    ),
    322 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '72cb0c49289b4ae12473a8cf6750bbe7',
      'native_key' => 'modx_browser_default_sort',
      'filename' => 'modSystemSetting/229cb0dc0ccf264a8786c6f0206292e3.vehicle',
    ),
    323 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'aa7041401d700a51edad0553f3dab312',
      'native_key' => 'modx_browser_default_viewmode',
      'filename' => 'modSystemSetting/e24db193dfd4f1b3bb62cd569fbee61e.vehicle',
    ),
    324 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f5967c6e135d89e121cf93f677a8952',
      'native_key' => 'modx_charset',
      'filename' => 'modSystemSetting/8bf00874b1bf6de53198b0469f319135.vehicle',
    ),
    325 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7f378909544c025b9749672570e678af',
      'native_key' => 'principal_targets',
      'filename' => 'modSystemSetting/dffec29e1b36107d44a03e380ee52c4c.vehicle',
    ),
    326 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '799b111f377cefcb98b858842c95aac9',
      'native_key' => 'proxy_auth_type',
      'filename' => 'modSystemSetting/886cc590557e27786b5a04fb8c7c5c47.vehicle',
    ),
    327 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e14e75aab091064e5f6c8e971f0b023b',
      'native_key' => 'proxy_host',
      'filename' => 'modSystemSetting/68a929dd26e1b890bcd605e9dca08b32.vehicle',
    ),
    328 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c0da09a942e11b1e3bfa3b2f27fa47f9',
      'native_key' => 'proxy_password',
      'filename' => 'modSystemSetting/630f00389272c1d837bd44601dd22059.vehicle',
    ),
    329 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c9945ea7af978e5ab6db81ac1f4ae7a',
      'native_key' => 'proxy_port',
      'filename' => 'modSystemSetting/4762abec77becc82e1a53d286f326da4.vehicle',
    ),
    330 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4805bf376c8209cfdaa3e6542247c03d',
      'native_key' => 'proxy_username',
      'filename' => 'modSystemSetting/aba9ad10d2d326c8884f8fb6141db835.vehicle',
    ),
    331 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a56c38f52f029d96575c5ddfe7844ea1',
      'native_key' => 'password_generated_length',
      'filename' => 'modSystemSetting/ce079f12a5aa21f9fe18a328e2d10f8f.vehicle',
    ),
    332 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '84cb9a56f47979d4f8df13a3a240ba4f',
      'native_key' => 'password_min_length',
      'filename' => 'modSystemSetting/ad35ed99938191c01d909e38717a09ff.vehicle',
    ),
    333 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e4c150cdded9643027c266d102dd1ddd',
      'native_key' => 'phpthumb_allow_src_above_docroot',
      'filename' => 'modSystemSetting/075da89957b4dc38e36fbf8c1365cb00.vehicle',
    ),
    334 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '473ec44124841dbdf464a8875b2bb763',
      'native_key' => 'phpthumb_cache_maxage',
      'filename' => 'modSystemSetting/f3c23d88ff26368a3d7a7ee0842429f9.vehicle',
    ),
    335 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '40c04adb90514cc8113342d65b239142',
      'native_key' => 'phpthumb_cache_maxsize',
      'filename' => 'modSystemSetting/29d0b46b675365390779e4ae56fea4cc.vehicle',
    ),
    336 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7d7bf588038ed7d18812cfdcfe45be85',
      'native_key' => 'phpthumb_cache_maxfiles',
      'filename' => 'modSystemSetting/10f2f70371d5a65366e8ecf1ddde9e91.vehicle',
    ),
    337 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '16cb9c682ab7b3d6c67aa580e80a4e3b',
      'native_key' => 'phpthumb_cache_source_enabled',
      'filename' => 'modSystemSetting/c445c60b0e3a536731064338d3dbcd46.vehicle',
    ),
    338 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7923777c24e86940d24a7d7336f47cb1',
      'native_key' => 'phpthumb_document_root',
      'filename' => 'modSystemSetting/f5c89675be331ddc117515e1335676ba.vehicle',
    ),
    339 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '3d03226c87187b44c38ffa775de8d094',
      'native_key' => 'phpthumb_error_bgcolor',
      'filename' => 'modSystemSetting/206244355508d826bf6a81717c9d4b25.vehicle',
    ),
    340 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2ff7cdee9d4930ed8b576197a09f2ec7',
      'native_key' => 'phpthumb_error_textcolor',
      'filename' => 'modSystemSetting/e52c9d2f1f9424922cde59a4599f7fc1.vehicle',
    ),
    341 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '99fddf50452b85767192b89994d6d61d',
      'native_key' => 'phpthumb_error_fontsize',
      'filename' => 'modSystemSetting/e606197166177956a54baca3afebe7cc.vehicle',
    ),
    342 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8d6c8af18cf02ad237d1bb97b9d9ef00',
      'native_key' => 'phpthumb_far',
      'filename' => 'modSystemSetting/81f9a785d97d0e6af548c2a0cf847d99.vehicle',
    ),
    343 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'a2259dee10999395f8e977511bc668bc',
      'native_key' => 'phpthumb_imagemagick_path',
      'filename' => 'modSystemSetting/63acf3c178acd7e223b2b9b1a149c920.vehicle',
    ),
    344 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cd0d691964de967058ce8d0ff6e3eb76',
      'native_key' => 'phpthumb_nohotlink_enabled',
      'filename' => 'modSystemSetting/29f929aa4b4af10d2519fd9dd143a1f7.vehicle',
    ),
    345 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b8b8321473b6547c750a42b92c7683d7',
      'native_key' => 'phpthumb_nohotlink_erase_image',
      'filename' => 'modSystemSetting/c965fc7f356d1aed44be74267aa1713f.vehicle',
    ),
    346 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b573f8be5de679522228c642ddc96dd8',
      'native_key' => 'phpthumb_nohotlink_valid_domains',
      'filename' => 'modSystemSetting/a8583bfd31ca61d86eb63305f3885375.vehicle',
    ),
    347 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '78f2c91c638b2739aa3f7d7dfdaffbfb',
      'native_key' => 'phpthumb_nohotlink_text_message',
      'filename' => 'modSystemSetting/1246bd9989265fda59e8f5a6154906cc.vehicle',
    ),
    348 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fafe910cef83950bbf237bbb8af52c19',
      'native_key' => 'phpthumb_nooffsitelink_enabled',
      'filename' => 'modSystemSetting/afe53af55992764e3c1520dec8f11945.vehicle',
    ),
    349 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5aaadba925d168eb0cff620279d1b9e5',
      'native_key' => 'phpthumb_nooffsitelink_erase_image',
      'filename' => 'modSystemSetting/78a133867e46b6b87fe048f2cb182f8f.vehicle',
    ),
    350 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '247e03fb24736af786c752834ff49cfb',
      'native_key' => 'phpthumb_nooffsitelink_require_refer',
      'filename' => 'modSystemSetting/41c49b0e07a2cf88e9c4d9494760f788.vehicle',
    ),
    351 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bbdd930b5a5d7cdfc7921cbeb7c877cd',
      'native_key' => 'phpthumb_nooffsitelink_text_message',
      'filename' => 'modSystemSetting/cf96cec0cefb8b6b39ffdcf389d837a2.vehicle',
    ),
    352 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ab6a3cc0315ec8ca0f4bb8faf85f6fea',
      'native_key' => 'phpthumb_nooffsitelink_valid_domains',
      'filename' => 'modSystemSetting/7a463286a8c4690afd5f92e2e77842b4.vehicle',
    ),
    353 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '1bbf46d1a4fcbbf8fd6d0fe189705453',
      'native_key' => 'phpthumb_nooffsitelink_watermark_src',
      'filename' => 'modSystemSetting/cd9fe45da835bd9efa0bf61481571283.vehicle',
    ),
    354 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'babc7d42ece87a4e22db237097dc8a38',
      'native_key' => 'phpthumb_zoomcrop',
      'filename' => 'modSystemSetting/ceb78d76648186a8678ed4881994bc35.vehicle',
    ),
    355 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '82c432d042f18505aead6974c2f8d930',
      'native_key' => 'publish_default',
      'filename' => 'modSystemSetting/45898286e760c3c94892dd10fd9664d9.vehicle',
    ),
    356 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2903a5a7bf6f62e56a233f412005320f',
      'native_key' => 'rb_base_dir',
      'filename' => 'modSystemSetting/e9b9fe5ad583382f19eae8734845f366.vehicle',
    ),
    357 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ead8b5bb0dee836a9016201736c2bd33',
      'native_key' => 'rb_base_url',
      'filename' => 'modSystemSetting/57f5065d4a0159d8653bc07ce2a7a805.vehicle',
    ),
    358 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c6476fd6379d8f197f6146e96d50d9b0',
      'native_key' => 'request_controller',
      'filename' => 'modSystemSetting/3fb6b65cf70b4f405590c172ab1f7dbd.vehicle',
    ),
    359 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e1a796ebb09f604597de58c49cb09738',
      'native_key' => 'request_method_strict',
      'filename' => 'modSystemSetting/91d0105df5906476e682238e728b82ad.vehicle',
    ),
    360 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f84a2a04abec41981f0f2c7c0b137868',
      'native_key' => 'request_param_alias',
      'filename' => 'modSystemSetting/fbba33c1020b9b9640c5856d257971fc.vehicle',
    ),
    361 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2edcd5ccdb056b407f1a52464ff5b9ff',
      'native_key' => 'request_param_id',
      'filename' => 'modSystemSetting/bbb81f7cbab451cef35c28aa21aed533.vehicle',
    ),
    362 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '58cdef3aa4759569c02f2463dc7cb887',
      'native_key' => 'resolve_hostnames',
      'filename' => 'modSystemSetting/46a491a8ee503832417946919937c7ab.vehicle',
    ),
    363 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b01504c6bc9dac9ede31cfc5969ecbc',
      'native_key' => 'resource_tree_node_name',
      'filename' => 'modSystemSetting/4c2323a8ef50c309ad450c3dc14f0d0c.vehicle',
    ),
    364 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '53800f4c31917d25ba148b46e29438cb',
      'native_key' => 'resource_tree_node_name_fallback',
      'filename' => 'modSystemSetting/30993229a79a6d5febd5c3dba7364bcf.vehicle',
    ),
    365 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '61198c3df7d411260ef2e7e94ab4b488',
      'native_key' => 'resource_tree_node_tooltip',
      'filename' => 'modSystemSetting/7d093245bbd814c3b31ab02f213623ac.vehicle',
    ),
    366 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b3dd8471ab290f596995749bc386578b',
      'native_key' => 'richtext_default',
      'filename' => 'modSystemSetting/8e7bdedf37142c63e86c88f4bf76076b.vehicle',
    ),
    367 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '890f0a5ba985603390de492b87a89659',
      'native_key' => 'search_default',
      'filename' => 'modSystemSetting/35a9f888e7d608549cfd1a1e4a36ec2d.vehicle',
    ),
    368 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '132a363cc5916ab4062a58ad6ec550ae',
      'native_key' => 'server_offset_time',
      'filename' => 'modSystemSetting/dd18aa7afd05f21b67fbae6b8ebc4b25.vehicle',
    ),
    369 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2bd9e98f350edf7468c913acd8efa72e',
      'native_key' => 'server_protocol',
      'filename' => 'modSystemSetting/f1ecb00ffcba897aaf49aa865fdd0ab1.vehicle',
    ),
    370 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd509db1926c88b4b86634dc9f0b676fc',
      'native_key' => 'session_cookie_domain',
      'filename' => 'modSystemSetting/590e5ec0cc49202986aaea7832b4f19e.vehicle',
    ),
    371 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '98eee3eec3dcc8eb93a4d881060ac32c',
      'native_key' => 'session_cookie_lifetime',
      'filename' => 'modSystemSetting/6c995ff610b0bdbeae61f372ffecf47a.vehicle',
    ),
    372 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2102bf458b6149d201554b2120577fcc',
      'native_key' => 'session_cookie_path',
      'filename' => 'modSystemSetting/7d1d36972515c435969761f8018ac6f5.vehicle',
    ),
    373 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '6b203badf3f0ae4b6610c81d66fdb894',
      'native_key' => 'session_cookie_secure',
      'filename' => 'modSystemSetting/30bfd84f12507d70be7a09f556298f33.vehicle',
    ),
    374 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8007b72edac1f75fdb22c6db1bf1b338',
      'native_key' => 'session_cookie_httponly',
      'filename' => 'modSystemSetting/064a5a2c05b4c5b1b784a56b97bffd90.vehicle',
    ),
    375 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ffd26aaa6a865e61c2b019c87893bda4',
      'native_key' => 'session_gc_maxlifetime',
      'filename' => 'modSystemSetting/1dc6e271df0b5fd6a918e9e89ca6f92a.vehicle',
    ),
    376 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59b43a017499fd2a4ccf8d06f88ed9eb',
      'native_key' => 'session_handler_class',
      'filename' => 'modSystemSetting/efdb50edfb8b1eb7d12a758ff5180908.vehicle',
    ),
    377 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a6fe42b67bb37e7df5f2b39b957edfa',
      'native_key' => 'session_name',
      'filename' => 'modSystemSetting/c12b0e62bb44c90aafbe5663b19431ac.vehicle',
    ),
    378 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '50ad67f112d1f64c33cf2774ad3c19f5',
      'native_key' => 'set_header',
      'filename' => 'modSystemSetting/bcd4f48a63041f0ecb695f48a12f587e.vehicle',
    ),
    379 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd5720a5b4b43cf1ead24775936109c95',
      'native_key' => 'show_tv_categories_header',
      'filename' => 'modSystemSetting/09f9ee79d8c8195c1bbf0cf322218c27.vehicle',
    ),
    380 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0e86d8af6522a533813f2e921f090d08',
      'native_key' => 'signupemail_message',
      'filename' => 'modSystemSetting/08faa4d09c18a655b7b8e43ddf504e63.vehicle',
    ),
    381 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '169285dc47b78aa207a0059b1243c29d',
      'native_key' => 'site_name',
      'filename' => 'modSystemSetting/edda82db4474b9d58df192f577e4d176.vehicle',
    ),
    382 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b1630a5c2c4d57508df93b84f9628404',
      'native_key' => 'site_start',
      'filename' => 'modSystemSetting/262afdc9ffd39b30120c68d36475938f.vehicle',
    ),
    383 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2c97a48f42ff37a79ca8bfc930ca74f5',
      'native_key' => 'site_status',
      'filename' => 'modSystemSetting/5a5f75fd31bf13620c4a3826aaa95b77.vehicle',
    ),
    384 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8f49e2627b9bec2bd6071a1a02f0c53a',
      'native_key' => 'site_unavailable_message',
      'filename' => 'modSystemSetting/bb0ae06b5253deb81bd79d13ca6950d7.vehicle',
    ),
    385 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'cec566f2ff565affd8f05aa3bb79cc7b',
      'native_key' => 'site_unavailable_page',
      'filename' => 'modSystemSetting/7a92c5ae7c3c0793eb879f1cc5a4b960.vehicle',
    ),
    386 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e91b25802c1381a714f87751227f465f',
      'native_key' => 'strip_image_paths',
      'filename' => 'modSystemSetting/7f76051d09e8f5a224598b002b97ec09.vehicle',
    ),
    387 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '2afcb8d1635d34b8fef6264f2412ef14',
      'native_key' => 'symlink_merge_fields',
      'filename' => 'modSystemSetting/38888ec56eb2f837cc302cbd4c156b6b.vehicle',
    ),
    388 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '79b01a9031ec5a9891643d85dd6ebc33',
      'native_key' => 'syncsite_default',
      'filename' => 'modSystemSetting/c1bd29a11afa78842572aa37fb82915b.vehicle',
    ),
    389 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '607ed261c45ea160e71ee0af5b23ed29',
      'native_key' => 'topmenu_show_descriptions',
      'filename' => 'modSystemSetting/97086ed8d131d2e3583c307ca5eed51d.vehicle',
    ),
    390 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '359a0751df73e5eabba795186a66173b',
      'native_key' => 'tree_default_sort',
      'filename' => 'modSystemSetting/85d228347fac61b9560e1e7cc152076f.vehicle',
    ),
    391 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88e1c667d6468480d54c2cbdc4cb1595',
      'native_key' => 'tree_root_id',
      'filename' => 'modSystemSetting/0aaa16235b115c72b7407c2ed54dca56.vehicle',
    ),
    392 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59ee28cd5015cfaa71a1ebfad7623f6e',
      'native_key' => 'tvs_below_content',
      'filename' => 'modSystemSetting/4083d3d5e53d394e7a2981e623b4609e.vehicle',
    ),
    393 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '252cd79b34951db766154b17ffcb42c5',
      'native_key' => 'udperms_allowroot',
      'filename' => 'modSystemSetting/940731a55c0e7b3f39399257c98d2678.vehicle',
    ),
    394 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'c801372eb474fa11a3de0e552298b162',
      'native_key' => 'unauthorized_page',
      'filename' => 'modSystemSetting/a831faaa1621c85f70e9cb96ec3b8516.vehicle',
    ),
    395 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '0dbf25b55a15791180790b8520dcb2f3',
      'native_key' => 'upload_files',
      'filename' => 'modSystemSetting/647ad4bcd6b5befdf5da88efb0a5ef2a.vehicle',
    ),
    396 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8bcda29d3b07f40e4bc89c53756a79a7',
      'native_key' => 'upload_flash',
      'filename' => 'modSystemSetting/57a2b79af4ab5ab44741223ca4098e6d.vehicle',
    ),
    397 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '14d634f3b309a3a27adcc2b8f90dfc2f',
      'native_key' => 'upload_images',
      'filename' => 'modSystemSetting/607b33a645eb44889341d63d5c9348ab.vehicle',
    ),
    398 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '43d5cb7fdc44fc0d3ccb323c1498c60d',
      'native_key' => 'upload_maxsize',
      'filename' => 'modSystemSetting/ec8ad6de38082e184d8a48101e39e8ac.vehicle',
    ),
    399 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '23444f2378d7347a2198a0b084f59867',
      'native_key' => 'upload_media',
      'filename' => 'modSystemSetting/3bc783d96899d4811fafac6690deb986.vehicle',
    ),
    400 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '88a96deb8872d46f6b99acc865ec5305',
      'native_key' => 'use_alias_path',
      'filename' => 'modSystemSetting/5c9ad3382177cb388ebb7445e477b7e6.vehicle',
    ),
    401 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4a00f032b824477d211e18b784b673d9',
      'native_key' => 'use_browser',
      'filename' => 'modSystemSetting/7a1f5f3eea0453fcae5ca8cb4fbe0ea9.vehicle',
    ),
    402 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'e529db6c4f2d04a61f5b6e5de27441a2',
      'native_key' => 'use_editor',
      'filename' => 'modSystemSetting/bddaa691815802e67da246066d7a3fbb.vehicle',
    ),
    403 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75c285d4a02e7d5a65e388b9f01aa826',
      'native_key' => 'use_multibyte',
      'filename' => 'modSystemSetting/53f510bb7e5f84ea20632d3508198ec3.vehicle',
    ),
    404 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9b000700f0b282fa89f5d4f4a4023068',
      'native_key' => 'use_weblink_target',
      'filename' => 'modSystemSetting/0571ab36fffde0b81325d74dc31b5c06.vehicle',
    ),
    405 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'd547e9907706b2e82a45f7f26663e5f2',
      'native_key' => 'webpwdreminder_message',
      'filename' => 'modSystemSetting/31969851740da3f01c7206f67ae5a0a6.vehicle',
    ),
    406 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '5a7ed0a198c9f0020bc16117f7f1ce5b',
      'native_key' => 'websignupemail_message',
      'filename' => 'modSystemSetting/5972e5df68e9ac48a4b2e3f21633d6b8.vehicle',
    ),
    407 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f108669196d14e216d978de47e0d7727',
      'native_key' => 'welcome_screen',
      'filename' => 'modSystemSetting/af5bbef60509ddca4137c9a2729f1225.vehicle',
    ),
    408 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '96185db674b7adf3026e43ceea9a5d20',
      'native_key' => 'welcome_screen_url',
      'filename' => 'modSystemSetting/05c64eb95f97d786c5c3b0980b3a68a5.vehicle',
    ),
    409 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'fc657aca68af1e8127828c8561a52a94',
      'native_key' => 'welcome_action',
      'filename' => 'modSystemSetting/e65af5a746ddcb0779afdc721ed8fb73.vehicle',
    ),
    410 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b072240959b04131bc73ae249d8b986b',
      'native_key' => 'welcome_namespace',
      'filename' => 'modSystemSetting/d7d13ae9582928ccaf7667772b700570.vehicle',
    ),
    411 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9d365d059c9e178f7ea516977ecfc178',
      'native_key' => 'which_editor',
      'filename' => 'modSystemSetting/0aaf67dec2b5fdd6df499c4a463b4885.vehicle',
    ),
    412 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '86809378c7c914a766e2ed9c7eb70c3b',
      'native_key' => 'which_element_editor',
      'filename' => 'modSystemSetting/f43ede6dee0e2abf8672ecf34cbec28a.vehicle',
    ),
    413 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ccf40656b80cb52faee8f1cb04c2c043',
      'native_key' => 'xhtml_urls',
      'filename' => 'modSystemSetting/87421f4172ca8ccc911ee79b353b45f2.vehicle',
    ),
    414 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '20546493602d098e5b09ac4b8421a407',
      'native_key' => 'enable_gravatar',
      'filename' => 'modSystemSetting/4fa3a10985ed8cefb1f8a2034b2a4764.vehicle',
    ),
    415 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f67834923be81744f922667a03b87c33',
      'native_key' => 'auto_isfolder',
      'filename' => 'modSystemSetting/3a8a4c27d4195e349d873f0f254f35a9.vehicle',
    ),
    416 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '0a2e5a67bac4c88969fcf620e11c43de',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'allow_tags_in_post',
      ),
      'filename' => 'modContextSetting/dc806d15e179bd540485f53e39b2d33a.vehicle',
    ),
    417 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContextSetting',
      'guid' => '907dd0fcb930cc4a271c6390a350c413',
      'native_key' => 
      array (
        0 => 'mgr',
        1 => 'modRequest.class',
      ),
      'filename' => 'modContextSetting/79187485188a7dd8056f7198e39da643.vehicle',
    ),
    418 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroup',
      'guid' => 'a9370f11bf559edb0e6691f34739a3f1',
      'native_key' => 1,
      'filename' => 'modUserGroup/1d0489d224583b1632802b581bdc562b.vehicle',
    ),
    419 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboard',
      'guid' => '7e85902bb5e93dba1481ce7d298b1c28',
      'native_key' => 1,
      'filename' => 'modDashboard/f77d41a80ae0dcaa9cc936af5c4acb13.vehicle',
    ),
    420 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMediaSource',
      'guid' => '8d22c3d2fde6444de0e28facab73e72c',
      'native_key' => 1,
      'filename' => 'modMediaSource/6e352be10d0022a8465b2ee6c8daa1a1.vehicle',
    ),
    421 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'cec6b8e06ed4cba16fa72f7e350c97b8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/21729dabc7165a98eb78a9ea4f3f8ade.vehicle',
    ),
    422 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => 'c43c202a8f4cea6d2880c9672d2523d5',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/3b6c6b8dc865102b532178556c3c6ccd.vehicle',
    ),
    423 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '2abdc5a5d9edec73a3a0cfee6b88729a',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/57c7fe84b0cd8783c8e89795c91c801f.vehicle',
    ),
    424 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '50d5a50b1ddc8f492eba4393a50589a8',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/2c98f26dfc211076996e82022280fa37.vehicle',
    ),
    425 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modDashboardWidget',
      'guid' => '206283e7784f17b8a4317e488f8f6eec',
      'native_key' => NULL,
      'filename' => 'modDashboardWidget/de6ada59f41ae1f25b1e43c33b2ce1a7.vehicle',
    ),
    426 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => '6ffee5ef4e5efb85c54e626c2e1c0e94',
      'native_key' => 1,
      'filename' => 'modUserGroupRole/dd6070ffac0060c68b21653b3ca8ce66.vehicle',
    ),
    427 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modUserGroupRole',
      'guid' => 'cb5416aab78d837d713070d8fdc673c6',
      'native_key' => 2,
      'filename' => 'modUserGroupRole/d9c1702f11e0ff3f29913dff9b0138ab.vehicle',
    ),
    428 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'ec316314023c3b7a511882bf1f58b6bd',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7f74af36c853c2939cf773f6a25dd3ee.vehicle',
    ),
    429 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '12e25d96cd75d9f33379d2ac49cac27d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/7e2c12789ae99df913838f549965dbf7.vehicle',
    ),
    430 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '7d130340fe59697d988cc395332537dc',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/5c6605131f01409be8769e3314e6f682.vehicle',
    ),
    431 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => '0f7a4f7ab0e30a6a469a9e3275e7f541',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/6ad0389ff57c867a7f57a5f939096a17.vehicle',
    ),
    432 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplateGroup',
      'guid' => 'b0fdc7297c537e0f7d1b9541a9e2156e',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplateGroup/05cbb86ed94e4b9ff00a62cfafcaa18d.vehicle',
    ),
    433 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'd228f7bf8ee533fa8992cd943716e4f2',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/4cdb9e52a03e840637be9c0b5e80fb98.vehicle',
    ),
    434 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'aea293afd89508a4a4c47f46f8c73043',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/29404ffd10b145d9c8ec70faf74807e8.vehicle',
    ),
    435 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => '23e84d86747c9a3baaee5e38f711741b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/64ca96f336ad2249cdc499e9d34f1391.vehicle',
    ),
    436 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'a2892878c5f07107ee17805f113d7b1a',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/9ed972057ebc4d6b7b2b5177ca4dc329.vehicle',
    ),
    437 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'fd1d52ae3825afaea022f34714ff6d1b',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/3677e66e67855dfe61a83a0d4b83d626.vehicle',
    ),
    438 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicyTemplate',
      'guid' => 'e5f8b64fa5c0e85148d14d5cccd97f9d',
      'native_key' => NULL,
      'filename' => 'modAccessPolicyTemplate/b8756f922e85bbb5db793171947cc9c9.vehicle',
    ),
    439 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '1e5527476ce1b17e0bf16ef0693e203e',
      'native_key' => 1,
      'filename' => 'modAccessPolicy/1ee36e0ef745add3ae95c82c6347fa1d.vehicle',
    ),
    440 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6aff2ab71c1f929b1c04d161a44f23eb',
      'native_key' => 2,
      'filename' => 'modAccessPolicy/3c2da052a16f6b9a591378ba7ef3cf88.vehicle',
    ),
    441 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'aa34bfa1c139358bbd756d2c333f788b',
      'native_key' => 3,
      'filename' => 'modAccessPolicy/747728e12762af00bb6934c2ae02c313.vehicle',
    ),
    442 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'fa43e86befaefaeb0cd4f51e6346bad9',
      'native_key' => 4,
      'filename' => 'modAccessPolicy/7d7bf41f572a7f6eb86f3aec8f2ccf02.vehicle',
    ),
    443 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '105b61be14442b43da9530fd3f899366',
      'native_key' => 5,
      'filename' => 'modAccessPolicy/7e721ad134c38be6831e0335daf3ec40.vehicle',
    ),
    444 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '0d1eb73d8c05d2b7adfe23ef6ab29f7d',
      'native_key' => 6,
      'filename' => 'modAccessPolicy/e3407a861651ad615691469c64034d70.vehicle',
    ),
    445 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'aa12d77378dc8cd3f21490d121ab8f01',
      'native_key' => 7,
      'filename' => 'modAccessPolicy/2aae92a939c0c911931181090e95c66a.vehicle',
    ),
    446 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'f86468c3e6cdf377eabf938671e82539',
      'native_key' => 8,
      'filename' => 'modAccessPolicy/23f926f32fdcc320671e40b443728d2a.vehicle',
    ),
    447 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '5c44da372504b8bb594824a7df28daa3',
      'native_key' => 9,
      'filename' => 'modAccessPolicy/cd2d71c5137a4e685342d22919738fdf.vehicle',
    ),
    448 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => 'b0f1bd69e025d80867b74185d8525d03',
      'native_key' => 10,
      'filename' => 'modAccessPolicy/4af109484b1233c29372f72b4820fed7.vehicle',
    ),
    449 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modAccessPolicy',
      'guid' => '6cf323a93cad4153ade83d324e8ae361',
      'native_key' => 11,
      'filename' => 'modAccessPolicy/9a8d370186af1a63d9b28114874c03ef.vehicle',
    ),
    450 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => 'b677f83a538ce93e4109f19adb64c47a',
      'native_key' => 'web',
      'filename' => 'modContext/e8cae724bd6ce2a2a2addb57ce2c7185.vehicle',
    ),
    451 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modContext',
      'guid' => '5776852a43b332b85dec5cded16bc75b',
      'native_key' => 'mgr',
      'filename' => 'modContext/59b7a7d7be576c7a5a86ad1426acc339.vehicle',
    ),
    452 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '59f69dc92896a3d06554a2bc52201162',
      'native_key' => '59f69dc92896a3d06554a2bc52201162',
      'filename' => 'xPDOFileVehicle/07c5c7df3a361132659bda5f23600da5.vehicle',
    ),
    453 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '70a3bf91b765bee976f71922ca1d8531',
      'native_key' => '70a3bf91b765bee976f71922ca1d8531',
      'filename' => 'xPDOFileVehicle/cc5182f205d7c6d42f4fd1a50a7f08ff.vehicle',
    ),
    454 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => 'fc9a4c1b9bab2ffe73908dac1805d958',
      'native_key' => 'fc9a4c1b9bab2ffe73908dac1805d958',
      'filename' => 'xPDOFileVehicle/7c5124fd13a0f8eaa76ed0c439cd3452.vehicle',
    ),
    455 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOFileVehicle',
      'class' => 'xPDOFileVehicle',
      'guid' => '99a4dda34998e9ef0fb511f4f35e5529',
      'native_key' => '99a4dda34998e9ef0fb511f4f35e5529',
      'filename' => 'xPDOFileVehicle/3f7250ed32f5c5060f13f857c5391619.vehicle',
    ),
  ),
);