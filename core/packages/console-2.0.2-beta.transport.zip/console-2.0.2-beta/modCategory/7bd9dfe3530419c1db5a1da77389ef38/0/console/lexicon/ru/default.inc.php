<?php

$_lang['console'] = 'Console';
$_lang['console_desc'] = 'Консоль для выполнения php-кода';
$_lang['console_tab'] = 'Редактор php-кода';
$_lang['console_exec'] = 'Выполнить';
$_lang['console_formated_result'] = 'Результат';
$_lang['console_source_result'] = 'Исходный код';
