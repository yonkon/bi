Console
=====================================================

Console allow to execute php-code at back-end by simple interface.
