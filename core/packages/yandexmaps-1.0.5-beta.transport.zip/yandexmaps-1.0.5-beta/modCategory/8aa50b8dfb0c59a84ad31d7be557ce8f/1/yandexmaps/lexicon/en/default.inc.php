<?php
/**
 * Default Russian Lexicon Entries for YandexMaps
 */

include_once 'setting.inc.php';

$_lang['yandexmaps'] = 'YandexMaps';
$_lang['yandexmaps_menu_desc'] = 'Компонент Яндекс Карты из ресурсов.';

$_lang['yandexmaps_pdotools_install'] = 'Install pdoTools';