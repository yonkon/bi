<?php
$location = 'vapor/';
require_once dirname(dirname(dirname(__FILE__))).'/index.php';