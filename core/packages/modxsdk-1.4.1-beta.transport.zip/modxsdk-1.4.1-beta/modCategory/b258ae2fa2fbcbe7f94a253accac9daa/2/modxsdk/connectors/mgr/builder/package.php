<?php
$location = 'builder/package/';
require_once dirname(dirname(dirname(__FILE__))).'/index.php';