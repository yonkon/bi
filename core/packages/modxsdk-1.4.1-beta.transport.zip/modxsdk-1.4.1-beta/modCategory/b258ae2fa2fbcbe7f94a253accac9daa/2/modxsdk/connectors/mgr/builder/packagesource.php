<?php
$location = 'builder/packagesource/';
require_once dirname(dirname(dirname(__FILE__))).'/index.php';