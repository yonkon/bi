<?php
$location = 'builder/vehicle/';
require_once dirname(dirname(dirname(__FILE__))).'/index.php';