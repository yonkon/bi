<?php
$location = 'model/objects/';
require_once dirname(dirname(dirname(__FILE__))).'/index.php';