<?php
 
require_once dirname(dirname(dirname(__FILE__))).'/index.class.php';

class ControllersMgrMainpanelManagerController extends ModxsdkControllersManagerController{
    
}

class ModxsdkControllersMgrMainpanelManagerController extends ControllersMgrMainpanelManagerController{
}
