<?php

class ModxsdkProjectGetListProcessor extends modObjectGetListProcessor{
    
    public $classKey = 'ModxsdkProject'; 
}

return 'ModxsdkProjectGetListProcessor';
?>
