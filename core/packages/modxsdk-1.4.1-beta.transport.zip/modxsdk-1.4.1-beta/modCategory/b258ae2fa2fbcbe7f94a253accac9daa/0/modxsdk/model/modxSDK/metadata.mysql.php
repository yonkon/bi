<?php

$xpdo_meta_map = array (
  'xPDOSimpleObject' => 
  array (
    0 => 'ModxsdkPackage',
    1 => 'ModxsdkProject',
    2 => 'ModxsdkVehicle',
  ),
  'xPDOObject' => 
  array (
    0 => 'ModxsdkPackageVehicle',
    1 => 'ModxsdkPackagesource',
    2 => 'ModxsdkProjectPackage',
  ),
);