<?php
require_once (dirname(dirname(__FILE__)) . '/modxsdkprojectpackage.class.php');
class ModxsdkProjectPackage_mysql extends ModxsdkProjectPackage {}