<?php

require_once MODX_PROCESSORS_PATH. 'browser/file/update.class.php';

class modxSDKFileUpdateProcessor extends modBrowserFileUpdateProcessor{
}

return 'modxSDKFileUpdateProcessor';