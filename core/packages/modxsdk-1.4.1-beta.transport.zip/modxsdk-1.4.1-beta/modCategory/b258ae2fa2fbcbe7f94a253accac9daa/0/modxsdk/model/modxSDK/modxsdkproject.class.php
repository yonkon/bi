<?php
class ModxsdkProject extends xPDOSimpleObject {}