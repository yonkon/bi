<?php

require_once MODX_PROCESSORS_PATH. 'browser/file/get.class.php';

class modxSDKFileGetProcessor extends modBrowserFileGetProcessor{
}

return 'modxSDKFileGetProcessor';