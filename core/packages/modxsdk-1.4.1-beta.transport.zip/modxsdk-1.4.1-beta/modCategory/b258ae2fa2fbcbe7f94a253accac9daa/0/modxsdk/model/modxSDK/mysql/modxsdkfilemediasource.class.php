<?php
require_once (dirname(dirname(__FILE__)) . '/modxsdkfilemediasource.class.php');
class ModxsdkFileMediaSource_mysql extends ModxsdkFileMediaSource {}