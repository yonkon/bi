<?php
require_once (dirname(dirname(__FILE__)) . '/modxsdkpackagevehicle.class.php');
class ModxsdkPackageVehicle_mysql extends ModxsdkPackageVehicle {}