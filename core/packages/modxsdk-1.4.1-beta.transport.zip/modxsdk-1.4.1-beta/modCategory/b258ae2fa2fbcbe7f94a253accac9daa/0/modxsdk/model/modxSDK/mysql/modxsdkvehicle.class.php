<?php
require_once (dirname(dirname(__FILE__)) . '/modxsdkvehicle.class.php');
class ModxsdkVehicle_mysql extends ModxsdkVehicle {}