<?php
require_once (dirname(dirname(__FILE__)) . '/modxsdkproject.class.php');
class ModxsdkProject_mysql extends ModxsdkProject {}