<?php
$xpdo_meta_map['ModxsdkFileMediaSource']= array (
  'package' => 'modxSDK',
  'version' => '1.1',
  'extends' => 'modFileMediaSource',
  'fields' => 
    array (
        'class_key' => 'ModxsdkFileMediaSource',
    ),
  'fieldMeta' => 
    array (),
);
