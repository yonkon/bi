<?php
require_once (dirname(dirname(__FILE__)) . '/modxsdkpackage.class.php');
class ModxsdkPackage_mysql extends ModxsdkPackage {}