<?php
require_once (dirname(dirname(__FILE__)) . '/modxsdkpackagesource.class.php');
class ModxsdkPackagesource_mysql extends ModxsdkPackagesource {}