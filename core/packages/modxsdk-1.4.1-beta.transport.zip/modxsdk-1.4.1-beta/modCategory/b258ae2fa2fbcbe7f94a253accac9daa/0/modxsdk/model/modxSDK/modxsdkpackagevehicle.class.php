<?php
class ModxsdkPackageVehicle extends xPDOObject {}