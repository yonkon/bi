<?php

/**
 * Description of create
 *
 * @author Fi1osof
 */
class ModxsdkProjectPackageCreateProcessor {
    
}


return 'ModxsdkProjectPackageCreateProcessor';
?>
